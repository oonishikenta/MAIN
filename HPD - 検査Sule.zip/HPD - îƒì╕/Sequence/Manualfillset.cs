﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Manualfillset
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Manualfillset(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                System.Windows.Forms.DialogResult ChkRslt = System.Windows.Forms.DialogResult.No;

                //精査コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.Examine);                //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                byte[] ReceiveData = OwnerP.RecvCheckAndGetData(recv); //recvからデータだけ取り出す
                if (ReceiveData != null)
                {
                    int amt = 0;
                    for (int i = 0; i < 48; i++)
                    {
                        amt += (ReceiveData[i] & 0x0F);
                    }
                    amt += (ReceiveData[96] & 0x0F);
                    if (amt != 0)
                    {
                        ChkRslt = SgNet.COM.MessageBox_s.ShowYesNo("在高が残っています。クリアしますか？");
                        if (ChkRslt == System.Windows.Forms.DialogResult.Yes)
                        {
                            int lenclr = 2;
                            byte[] dtclr = new byte[lenclr];        //データ部仮配列
                            dtclr[0] = 0x3F;                        //D0・在高クリア部位指定（１５：カセット、ＲＪ部すべて）
                            dtclr[1] = 0x30;                        //D1・０固定

                            //在高クリアコマンド
                            data = OwnerP.MakeSendData((byte)SQMain.CmdCode.AmountClear, lenclr, dtclr);    //コマンド,データ長,データ部配列
                            recv = OwnerP.Send(data, 1500);                 //送信
                            if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                            {
                                err = true;
                                OwnerP.GetErrorByConditionRead();
                                break;
                            }
                        }
                    }
                }
                else
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }


                int len = 6;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・設定機種
                dt[1] = 0x31;                   //D1・設定機種（１：紙幣部固定）
                dt[2] = 0x31;                   //D2・ＳＷNo.（16^1）
                dt[3] = 0x32;                   //D3・ＳＷNo.（16^0）（１８(0x12)：在高管理設定）
                dt[4] = 0x30;                   //D4・設定データ（16^1）
                dt[5] = 0x31;                   //D5・設定データ（16^0）（１：手詰め補充許可）

                //ＳＳＷ設定コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWWrite, len, dt);    //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
