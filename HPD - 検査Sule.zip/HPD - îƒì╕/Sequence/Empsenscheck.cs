﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Empsenscheck
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Empsenscheck(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //ＲＡＳセンスの状態enum
        private enum MovechkCond { STOP, OPERATE }
        byte[] ReceiveData;

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                //機種を確認し、チャージ機（インタラプタなし仕様）なら処理せずにＯＫとする
                err = Portread();

                if (err == false)
                {
                    if ((ReceiveData[24] & 0x04) != 0)              //チャージ機（インタラプタなし仕様）なら処理しない
                    {
                        //ＲＡＳ終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);             //送信
                        if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                        break;
                    }
                }
                //（ここまで）・機種を確認し、チャージ機（インタラプタなし仕様）なら処理せずにＯＫとする

                //カセットレバーを動かし、インタラプタの透光を確認する
                int len = 2;
                byte[] dt = new byte[len];      //データ部仮配列

                if (err == false)
                {
                    dt[0] = 0x31;                   //D0・動作内容指定（１：カセットレバー位置移動）
                    dt[1] = 0x32;                   //D1・動作箇所（２：カセット３）

                    //駆動部動作チェックコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASmovecheck, len, dt);     //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                if (err == false)
                {
                    do
                    {
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);                                         //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                    } while (ReceiveData[10] == (byte)MovechkCond.OPERATE);

                    if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                    {
                        //ＲＡＳ継続動作終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                   //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);             //送信
                        if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                    }
                }

                if (err == false)
                {
                    err = Portread();                           //ポートリードコマンド

                    if (err == false)
                    {
                        if ((ReceiveData[19] & 0x08) == 0)              //透光なら異常
                        {
                            err = true;
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 0, "传感器状态异常", System.Drawing.Color.Red);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 0, "センサ状態異常（遮光時）", System.Drawing.Color.Red);
                                    break;
                            }
                        }
                    }
                }
                //（ここまで）・カセットレバーを動かし、インタラプタの透光を確認する
                SgNet.COM.Time_s.Sleep(1500);

                //カセットレバーを動かし、インタラプタの遮光を確認する
                if (err == false)
                {
                    dt[0] = 0x31;                   //D0・動作内容指定（１：カセットレバー位置移動）
                    dt[1] = 0x32;                   //D1・動作箇所（２：カセット３）

                    //駆動部動作チェックコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASmovecheck, len, dt);     //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                if (err == false)
                {
                    do
                    {
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);                                         //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                    } while (ReceiveData[10] == (byte)MovechkCond.OPERATE);

                    if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                    {
                        //ＲＡＳ継続動作終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                   //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);             //送信
                        if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                    }
                }

                if (err == false)
                {
                    err = Portread();                           //ポートリードコマンド

                    if (err == false)
                    {
                        if ((ReceiveData[19] & 0x08) != 0)              //遮光なら異常
                        {
                            err = true;
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 0, "传感器状态异常", System.Drawing.Color.Red);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 0, "センサ状態異常（透光時）", System.Drawing.Color.Red);
                                    break;
                            }
                        }
                    }
                }
                //（ここまで）・カセットレバーを動かし、インタラプタの遮光を確認する

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }

        bool Portread(){
            bool err = false;

            //ポートリードコマンド
            byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASportread);       //コマンド（データ長０のもの）
            byte[] recv = OwnerP.Send(data, 1500);                 //送信
            if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
            {
                err = true;
                OwnerP.GetErrorByRASsense();
            }

            if (err == false)
            {
                //ＲＡＳセンスコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);  //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);         //送信
                ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す
                if (ReceiveData == null)
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                if (recv != null)           //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ継続動作終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                   //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }
            }
            return err;
        }

        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
