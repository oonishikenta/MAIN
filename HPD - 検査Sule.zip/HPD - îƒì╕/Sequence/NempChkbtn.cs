﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Simulator
{
    public partial class NempChkbtn : Form
    {
        public NempChkbtn()
        {
            InitializeComponent();
            button1.Focus();
            timer1.Enabled = true;
            timer2.Enabled = true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            NempChkSyukkin.ChkRslt = 1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NempChkSyukkin.ChkRslt = -1;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (NempChkSyukkin.checkdone == true)
            {
                label1.ForeColor = Color.Red;
                label1.Text = "●";
                if (NempChkSyukkin.ChkRslt == 0)
                {
                    button1.Enabled = true;
                    button2.Enabled = true;
                    label5.Visible = true;
                }
                else
                {
                    button1.Enabled = false;
                    button2.Enabled = false;
                    label5.Visible = false;
                }
            }
            else
            {
                label1.ForeColor = Color.Black;
                label1.Text = "○";
                button1.Enabled = false;
                button2.Enabled = false;
                label5.Visible = false;
            }
            label2.Text = NempChkSyukkin.pcs.ToString();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (button1.Enabled == true)
            {
                Thread.Sleep(1000);
                //Bitmap bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
                ////Graphicsの作成
                //Graphics g = Graphics.FromImage(bmp);
                ////画面全体をコピーする
                //g.CopyFromScreen(new Point(0, 0), new Point(0, 0), bmp.Size);
                ////解放
                //g.Dispose();

                //var path = Application.StartupPath;
                //System.IO.Path.Combine(path, "Image", DateTime.Now.ToShortDateString().Replace("/","") + DateTime.Now.ToLongTimeString().Replace(":",""));
                //bmp.Save(path);
                this.button1_Click(sender, e);
                timer2.Stop();
            }
        }
    }
}
