﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Unitinfo
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Unitinfo(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        string[] Dataname = { "MACHINEcode", "MAINver", "MAINsum", "BVver", "BVsum", "ICver", "ICsum", "DETAILcode" };

        static int Paramcount = 8;

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                string versionParam = CmdP.Parameter;                                   //パラメータの欄から文字列を取得する
                string[] versionData_para = versionParam.Split(',');                    //カンマ区切りで分割して配列に格納する
                if (versionData_para.Length != Paramcount)
                {
                    err = true;
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            OwnerP.ChangeInfo(0, 0, "参数异常", System.Drawing.Color.Red);
                            break;
                        case "JP":
                            OwnerP.ChangeInfo(0, 0, "パラメータ異常", System.Drawing.Color.Red);
                            break;
                    }
                    break;
                }

                string[] versionData_resp = new string[Paramcount];

                //バージョンリードコマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.Verread);        //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);                                  //送信
                byte[] ReceiveData = OwnerP.RecvCheckAndGetData(recv);                  //recvからデータだけ取り出す

                if (ReceiveData != null)
                {
                    //バージョン文字列の生成
                    //CharMerge(a,b)：データ２バイトの下部４ビットずつをまとめて１バイトにする
                    int i;
                    for (i = 0; i < 16; i += 2)
                    {
                        versionData_resp[0] += Convert.ToChar(OwnerP.CharMerge(ReceiveData[i], ReceiveData[i + 1]));    //機種コード
                    }
                    for (     ; i < 24; i += 2)
                    {
                        versionData_resp[1] += Convert.ToChar(OwnerP.CharMerge(ReceiveData[i], ReceiveData[i + 1]));    //本体バージョン
                    }
                    for (     ; i < 32; i += 2)
                    {
                        versionData_resp[2] += Convert.ToChar(OwnerP.CharMerge(ReceiveData[i], ReceiveData[i + 1]));    //本体ＳＵＭ
                    }
                    for (     ; i < 40; i += 2)
                    {
                        versionData_resp[3] += Convert.ToChar(OwnerP.CharMerge(ReceiveData[i], ReceiveData[i + 1]));    //識別バージョン
                    }
                    for (     ; i < 48; i += 2)
                    {
                        versionData_resp[4] += Convert.ToChar(OwnerP.CharMerge(ReceiveData[i], ReceiveData[i + 1]));    //識別ＳＵＭ
                    }
                    for (     ; i < 56; i += 2)
                    {
                        versionData_resp[5] += Convert.ToChar(OwnerP.CharMerge(ReceiveData[i], ReceiveData[i + 1]));    //ＩＣバージョン
                    }
                    for (     ; i < 64; i += 2)
                    {
                        versionData_resp[6] += Convert.ToChar(OwnerP.CharMerge(ReceiveData[i], ReceiveData[i + 1]));    //ＩＣＳＵＭ
                    }
                }
                else
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                int len = 4;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・アドレス指定（０固定）
                dt[1] = 0x30;                   //D1・アドレス指定（０固定）
                dt[2] = 0x30;                   //D2・アドレス指定（０固定）
                dt[3] = 0x30;                   //D3・アドレス指定（０固定）

                //メモリリードコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.Memread, len, dt);      //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                                         //送信
                ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す

                if (ReceiveData != null)
                {
                    //バージョン文字列の生成
                    for (int i = 0; i < 26; i += 2)
                    {
                        //CharMerge(a,b)：データ２バイトの下部４ビットずつをまとめて１バイトにする
                        versionData_resp[7] += Convert.ToChar(OwnerP.CharMerge(ReceiveData[i], ReceiveData[i + 1]));
                    }
                    //調整値をファイル保存
                    List<string[]> InfoData = new List<string[]>();
                    string[][] InfoDataVal = new string[Paramcount][];
                    string DispData = "";
                    for (int i = 0; i < Paramcount; i++)
                    {
                        string[] SensValue = new string[2];
                        InfoDataVal[i] = SensValue;
                        InfoDataVal[i][0] = Dataname[i];
                        InfoDataVal[i][1] = versionData_resp[i];
                        InfoData.Add(InfoDataVal[i]);
                        DispData += InfoDataVal[i][0] + "\t" + InfoDataVal[i][1] + "\r\n";
                    }
                    OwnerP.ChangeInfo(2, 0, DispData, System.Drawing.Color.White);
                    OwnerP.Savevalue("Unitinfo.csv", InfoData);
                }
                else
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //データ比較
                for (int n = 0; n < Paramcount; n++) { 
                    if (versionData_para[n] != versionData_resp[n])
                    {
                        err = true;
                        switch (OwnerP.Lang)
                        {
                            case "CN":
                                OwnerP.ChangeInfo(0, 0, "数据不一样 : " + Dataname[n], System.Drawing.Color.Red);
                                break;
                            case "JP":
                                OwnerP.ChangeInfo(0, 0, "データ不一致 : " + Dataname[n], System.Drawing.Color.Red);
                                break;
                        }
                        break;  //forを抜ける
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
