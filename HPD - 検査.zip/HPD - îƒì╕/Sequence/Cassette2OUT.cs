﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Cassette2OUT
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Cassette2OUT(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                int len = 13;
                byte[] dt = new byte[len];      //データ部仮配列

                //カセットをポップアップするため、SD1～SD3をＯＮにしてロックを外す
                dt[0] = 0x30;                   //D0・DCM1
                dt[1] = 0x30;                   //D1・DCM2
                dt[2] = 0x30;                   //D2・STM1
                dt[3] = 0x30;                   //D3・CL1
                dt[4] = 0x30;                   //D4・SD1
                dt[5] = 0x31;                   //D5・SD2（１：ＯＮ）
                dt[6] = 0x30;                   //D6・SD3
                dt[7] = 0x30;                   //D7・SD6
                dt[8] = 0x30;                   //D8・RSD1
                dt[9] = 0x30;                   //D9・RSD2
                dt[10] = 0x30;                  //D10・RSD3
                dt[11] = 0x30;                  //D11・RSD4
                dt[12] = 0x30;                  //D12・RSD5

                //駆動部単体動作コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsinglemove, len, dt);        //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                if (err == false)
                {
                    //ＲＡＳ継続動作終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                   //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                switch (OwnerP.Lang)
                {
                    case "CN":
                        SgNet.COM.MessageBox_s.ShowInfomation("请交换盒式２");
                        break;
                    case "JP":
                        SgNet.COM.MessageBox_s.ShowInfomation("カセット２を交換してください");
                        break;
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
