﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Sens17adjust
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        public static bool AdjEndflg = false;
        public static bool Senscondflg = false;

        //コンストラクタ
        public Sens17adjust(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //ＲＡＳセンスの状態enum
        private enum SensadjCond { STOP, OPERATE }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                byte addr = 19;
                byte bit = 8;
                int nowVal = 0;

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);   //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                //ポートリードコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASportread);       //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                if (err == false)
                {
                    byte[] ReceiveData;
                    bool Firstflg = false;

                    AdjEndflg = false;
                    Sens17adjbtn FormSens17 = new Sens17adjbtn();
                    FormSens17.Show();

                    do
                    {
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);  //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);         //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if (Firstflg == false)
                        {
                            nowVal = ReceiveData[addr] & bit;
                            Firstflg = true;
                        }
                        if ((ReceiveData[addr] & bit) != 0)
                        {
                            Senscondflg = true;
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 2, "(PS17) 关", System.Drawing.Color.Green);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 2, "(PS17) 遮光", System.Drawing.Color.Green);
                                    break;
                            }
                        }
                        else
                        {
                            Senscondflg = false;
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 2, "(PS17) 开", System.Drawing.Color.YellowGreen);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 2, "(PS17) 透光", System.Drawing.Color.YellowGreen);
                                    break;
                            }
                        }
                    } while (AdjEndflg == false);

                    do
                    {
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);                                         //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                    } while (ReceiveData[10] == (byte)SensadjCond.OPERATE);
                    OwnerP.ChangeInfo(0, 2, " ", System.Drawing.Color.White);

                    //ＲＡＳ継続動作終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);           //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);                 //送信
                    if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);        //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
