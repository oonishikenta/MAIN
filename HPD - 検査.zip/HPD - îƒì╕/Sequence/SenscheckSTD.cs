﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class SenscheckSTD
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public SenscheckSTD(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        string[] Sensname = { "PS3OU", "PS2", "PS1B", "PS1A", "PS4", "PS3OL", "PS3L", "PS3U",
                              "PS7R", "PS7L", "PS6", "PS5", "PS11", "PS10", "PS9", "PS8",
                              "PS16", "PS15", "PS14", "PS12", "YOBI", "YOBI", "YOBI", "PS17",
                              "PI4", "PI3", "PI2", "PI1", "PI10", "PI8", "PI6", "PI5",
                              "PI20", "PI17", "PI16", "PI12", "YOBI", "YOBI", "PI22", "PI21" };

        //ＲＡＳセンスの状態enum
        private enum SensadjCond { STOP, OPERATE }
        private enum SensadjResult { NORMAL_END, ERROR_END }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                int len = 1;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・センサチェック内容（０：標準）

                //センサチェックコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsenscheck, len, dt);         //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                byte[] ReceiveData;
                if (err == false)
                {
                    do
                    {
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);                                         //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                    } while (ReceiveData[1] == (byte)SensadjCond.OPERATE);

                    if (err == false)
                    {
                        if (ReceiveData[4] == (byte)SensadjResult.ERROR_END)
                        {
                            err = true;

                            for (int n = 0; n < 20; n++)
                            {
                                if (ReceiveData[10 + n] != 0)
                                {
                                    byte rdata = ReceiveData[10 + n];
                                    string sname = "";

                                    if ((rdata & 0xF0) != 0)
                                    {
                                        sname = Sensname[2 * n];
                                    }
                                    else if ((rdata & 0x0F) != 0)
                                    {
                                        sname = Sensname[2 * n + 1];
                                    }
                                    switch (OwnerP.Lang)
                                    {
                                        case "CN":
                                            OwnerP.ChangeInfo(0, 0, "传感器检查异常 : " + sname, System.Drawing.Color.Red);
                                            break;
                                        case "JP":
                                            OwnerP.ChangeInfo(0, 0, "センサチェック異常 : " + sname, System.Drawing.Color.Red);
                                            break;
                                    }
                                }
                            }

                            OwnerP.GetErrorByRASsense();
                        }
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
