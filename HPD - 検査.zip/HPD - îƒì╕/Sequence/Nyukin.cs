﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Nyukin
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Nyukin(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //計数枚数のデータ部（10000円,5000円,2000円,1000円）
        //2000円に対するオフセット
        int[] MaisuHeader = { 3, 6, 0, 9 };
        int[] Fullpcs = { 200, 200, 0, 600 };

        //計数データリードの装置状態enum
        private enum HopperInfo { NONE, EXIST }
        private enum DetailInfo { OTHER, WAIT, MOVE, YOBI3, RJREMOVE, FULL, YOBI6, YOBI7, HPREMOVE }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                List<int> DispPCS = new List<int>();            //指示枚数、計数枚数を表示するための枚数データ格納リスト
                DispPCS.Clear();
                int pcs;
                bool fullNyukinFlg = false;

                int[] CountPcs_para = new int[CmdP.Maisu.Count];
                int[] CountPcs_resp = new int[CmdP.Maisu.Count];
                int[] CountPcs_cnt = new int[CmdP.Maisu.Count];

                //指示枚数が999の場合はフルまで入金するためカウンタを参照する
                for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                {
                    //コマンドのデータCmdP.Maisu[a]から指示枚数を取得
                    if (!int.TryParse(CmdP.Maisu[a], out pcs)) { pcs = 0; }
                    if (pcs == 999) { fullNyukinFlg = true; break; }
                }
                if (fullNyukinFlg == true)  //999枚設定があったら
                {
                    //精査コマンド
                    byte[] cntdata = OwnerP.MakeSendData((byte)SQMain.CmdCode.Examine);                //コマンド（データ長０のもの）
                    byte[] cntrecv = OwnerP.Send(cntdata, 60000);          //送信   マイン修正
                    byte[] cntReceiveData = OwnerP.RecvCheckAndGetData(cntrecv); //recvからデータだけ取り出す
                    if (cntReceiveData != null)
                    {
                        for (int a = 0; a < CmdP.Maisu.Count; a++)  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                        {
                            pcs = 0;
                            for (int b = 0; b < 3; b++)             //カセット（３つ）分ループ
                            {
                                int offset = b * 12;                //カセット１つあたりの枚数データ（１２バイト）分だけオフセット
                                                                    //計数枚数のデータ部
                                                                    //D0~D2 +D12~D14+D24~D26　  2000円合計枚数
                                                                    //D3~D5 +D15~D17+D27~D29 　10000円合計枚数
                                                                    //D6~D8 +D18~D20+D30~D32　  5000円合計枚数
                                                                    //D9~D11+D21~D23+D33~D35    1000円合計枚数
                                                                    //合計計数枚数を取得　MaisuHeader[a]でオフセットを考慮
                                CountPcs_cnt[a] += (cntReceiveData[offset + MaisuHeader[a]] & 0x0F) * 100
                                                + (cntReceiveData[offset + MaisuHeader[a] + 1] & 0x0F) * 10
                                                + (cntReceiveData[offset + MaisuHeader[a] + 2] & 0x0F);
                            }
                        }
                    }
                    else
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;
                    }
                }

                bool freeflg = true;
                for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                {
                    //コマンドのデータCmdP.Maisu[a]から指示枚数を取得
                    if (!int.TryParse(CmdP.Maisu[a], out pcs)) { pcs = 0; }
                    if (pcs == 999)
                    {
                        pcs = Fullpcs[a] - CountPcs_cnt[a];
                    }
                    DispPCS.Add(pcs);
                    CountPcs_para[a] = pcs;
                    if (pcs != 0)               //指示枚数がある場合、指示枚数のみ入金する設定にする
                    {                           //指示枚数がすべて０の場合は除く（１回のみ計数とする）
                        freeflg = false;
                    }
                }
                OwnerP.ChangeMaisu(DispPCS, 0);                 //指示枚数を表示
                for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                {
                    DispPCS[a] = 0;                             //０クリアして計数枚数表示に使用
                }
                OwnerP.ChangeMaisu(DispPCS, 1);                 //計数枚数を表示

                int len = 6;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・設定機種
                dt[1] = 0x31;                   //D1・設定機種（１：紙幣部固定）
                dt[2] = 0x33;                   //D2・ＳＷNo.（16^1）
                dt[3] = 0x32;                   //D3・ＳＷNo.（16^0）（５０(0x32)：入金限度枚数超過の判定設定）
                dt[4] = 0x30;                   //D4・設定データ（16^1）（０固定）
                if (freeflg)                    //D5・設定データ（16^0）
                { dt[5] = 0x30; }
                else
                {
                    if (CountPcs_para[3] > 200)
                    { dt[5] = 0x37; }
                    else
                    { dt[5] = 0x3F; }
                }

                //ＳＳＷ設定コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWWrite, len, dt);    //コマンド,データ長,データ部配列
                byte[] recv = OwnerP.Send(data, 60000);          //送信   マイン修正
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                if (!freeflg)
                {
                    for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        dt[2] = 0x33;                   //D2・ＳＷNo.（16^1）
                        dt[3] = (byte)(0x33 + a);       //D3・ＳＷNo.（16^0）（５１～５４：入金限度枚数設定）
                        if ((a == 3) && (CountPcs_para[3] > 200))
                        {
                            dt[4] = 0x30;               //D4・設定データ（16^1）
                            dt[5] = 0x30;               //D5・設定データ（16^0）
                        }
                        else
                        {
                            dt[4] = (byte)(0x30 | (CountPcs_para[a] / 16));    //D4・設定データ（16^1）
                            dt[5] = (byte)(0x30 | (CountPcs_para[a] % 16));    //D5・設定データ（16^0）
                        }
                        //ＳＳＷ設定コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWWrite, len, dt);    //コマンド,データ長,データ部配列
                        recv = OwnerP.Send(data, 60000);          //送信   マイン修正
                        if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByConditionRead();
                            break;
                        }
                    }
                }

                //預かり金計数開始コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.CountStart);             //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 60000);                 //送信  マイン修正
                if (OwnerP.RespCheck(recv, true))               //レスポンスチェック（ENQ待ちあり）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時に計数停止コマンドと計数終了コマンドを送信するようにする

                byte[] ReceiveData;
                bool Firstflg = false;
                bool Endflg = false;
                do
                {
                    if (OwnerP.ForceStopFlg)
                    {
                        err = true;
                        break;
                    }
                    //計数データリードコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.CountdataRead);             //コマンド（データ長０のもの）
                    //（ここだけ他の通信と並行になるのでタイムアウト（１０倍）を延ばす）
                    SgNet.COM.Time_s.Sleep(500);                                //0.5秒スリープ
                    recv = OwnerP.Send(data, 60000);                            //送信
                    ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す

                    if (ReceiveData == null)
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;  //whileを抜ける
                    }

                    DispPCS.Clear();
                    for (int a = 0; a < CmdP.Maisu.Count; a++)  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        //計数枚数のデータ部
                        //D 7~D 9 　10000円合計枚数
                        //D10~D12　  5000円合計枚数
                        //D13~D15　  2000円合計枚数
                        //D16~D18    1000円合計枚数
                        //計数枚数を取得
                        pcs = (ReceiveData[a * 3 + 7] & 0x0F) * 100
                            + (ReceiveData[a * 3 + 8] & 0x0F) * 10
                            + (ReceiveData[a * 3 + 9] & 0x0F);
                        DispPCS.Add(pcs);
                        CountPcs_resp[a] = pcs;
                    }
                    OwnerP.ChangeMaisu(DispPCS, 1);             //計数枚数を表示

                    //Firstflg：実際に計数を開始したかどうか（D3でみる）　指示枚数０の場合は１回計数で終了
                    if ((Firstflg == false) && (ReceiveData[3] == (byte)HopperInfo.EXIST))
                    {
                        Firstflg = true;
                        Endflg = false;
                        continue;
                    }
                    //Endflg：計数中かどうか（D4でみる）　計数動作中、抜き取り待ちの場合はfalseとする
                    Endflg = true;
                    if (ReceiveData[4] == (byte)DetailInfo.MOVE
                        || ReceiveData[4] == (byte)DetailInfo.RJREMOVE
                        || ReceiveData[4] == (byte)DetailInfo.HPREMOVE)
                    {
                        Endflg = false;
                    }
                    for (int a = 0; a < CmdP.Maisu.Count; a++)                  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        if (CountPcs_resp[a] < CountPcs_para[a])                //計数枚数に達していなければfalseとする
                        {
                            Endflg = false;
                        }
                    }

                } while ((Firstflg == false) || (Endflg == false));

                //ここまで（エラー時にコマンド送信）

                if (recv != null)               //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //計数停止コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.CountStop); //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 60000);             //送信   マイン修正
                    if (OwnerP.RespCheck(recv, false))           //レスポンスチェック（ENQ待ちなし）ENQ判定は下で行う
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                    }

                    //ここだけ個別にENQを送信し、計数停止を待つ
                    data = OwnerP.MakeSingleChar((byte)SQMain.CtrlChar.ENQ);
                    while (true)
                    {
                        SgNet.COM.Time_s.Sleep(50);       //0.05秒スリープ（反応を早くしてみる）
                        recv = OwnerP.Send(data, 60000);   //送信  マイン修正

                        if (recv == null)                 //無応答
                        {
                            //エラー終了
                            err = true;
                            OwnerP.GetErrorByConditionRead();
                            break;
                        }
                        else
                        {
                            if (recv[0] == (byte)SQMain.CtrlChar.SOH)  //SOH・計数中
                            {
                                continue;
                            }
                            else if (recv[0] == (byte)SQMain.CtrlChar.EM)   //EM・計数停止中
                            {
                                break;
                            }
                            else
                            {
                                err = true;
                                OwnerP.GetErrorByConditionRead();
                                break;
                            }
                        }
                    }

                    //計数終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.CountEnd);  //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 60000);             //送信  マイン修正
                    if (OwnerP.RespCheck(recv, true))           //レスポンスチェック（ENQ待ちあり）
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                    }

                    len = 6;
                    dt = new byte[len];             //データ部仮配列
                    dt[0] = 0x30;                   //D0・設定機種
                    dt[1] = 0x31;                   //D1・設定機種（１：紙幣部固定）
                    dt[2] = 0x33;                   //D2・ＳＷNo.（16^1）
                    dt[3] = 0x32;                   //D3・ＳＷNo.（16^0）（５０(0x32)：入金限度枚数超過の判定設定）
                    dt[4] = 0x30;                   //D4・設定データ（16^1）（０固定）
                    dt[5] = 0x30;                   //D5・設定データ（16^0）（０：設定解除）

                    //ＳＳＷ設定コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWWrite, len, dt);    //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 60000);          //送信  マイン修正
                    if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;
                    }
                    for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        dt[2] = 0x33;               //D2・ＳＷNo.（16^1）
                        dt[3] = (byte)(0x33 + a);   //D3・ＳＷNo.（16^0）（５１～５４：入金限度枚数設定）
                        //ＳＳＷ設定コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWWrite, len, dt);    //コマンド,データ長,データ部配列
                        recv = OwnerP.Send(data, 60000);          //送信  マイン修正
                        if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByConditionRead();
                            break;
                        }
                    }

                }
                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
