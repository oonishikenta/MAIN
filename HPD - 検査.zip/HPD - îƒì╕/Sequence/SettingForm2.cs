﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Simulator
{
    public partial class SettingForm2 : Form
    {
        public int JyokenNo;
        public CmdSequenceForm OwnerP;
        public IfClass ifClassBuf = new IfClass();
        public SettingForm2(CmdSequenceForm ownerP, IfClass p, int jyouken)
        {
            OwnerP = ownerP;
            JyokenNo = jyouken;
            ifClassBuf = (IfClass)DeepCopyClone((object)(p));
            InitializeComponent();
        }
        /// <summary>
        /// 対象オブジェクトのディープコピークローンを取得します。
        /// </summary>
        /// <typeparam name="T">対象オブジェクトの型</typeparam>
        /// <param name="target">コピー対象オブジェクトを指定します。</param>
        /// <returns>ディープコピーのクローンを返します。</returns>
        /// <remarks>このメソッドでディープコピーするには、対象クラスがシリアライズ可能である必要があります。</remarks>
        public T DeepCopyClone<T>(T target)
        {
            object clone = null;
            using (MemoryStream stream = new MemoryStream())
            {
                //対象オブジェクトをシリアライズ
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, target);
                stream.Position = 0;

                //シリアライズデータをデシリアライズ
                clone = formatter.Deserialize(stream);
            }
            return (T)clone;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            comboBox2.Items.Add("");
            for (int a = 0; a < OwnerP.CommandList.Count; a++)
            {
                comboBox2.Items.Add(OwnerP.CommandList[a]);
            }
            IfStatusInfo ddd2 = new IfStatusInfo();
            SettingForm3 ddd = new SettingForm3(OwnerP, ddd2);
            for (int a = 0; a < ifClassBuf.StatusInfoList.Count; a++)
            {
                listBox2.Items.Add(ddd.GetNameStr(ifClassBuf.StatusInfoList[a]));
            }
            textBox1.Text = ifClassBuf.HyoujiName;
            switch(ifClassBuf.RunRule)
            {
                case 0: radioButton1.Checked = true; break;
                case 1: radioButton2.Checked = true; break;
                case 2: radioButton3.Checked = true; break;
            }
            switch(ifClassBuf.UnitRowNo)
            {
                case 0: radioButton4.Checked = true; break;
                case 1: radioButton5.Checked = true; break;
                case 2: radioButton6.Checked = true; break;
            }
            switch(ifClassBuf.EndWaitRule)
            {
                case 0: radioButton7.Checked = true; break;
                case 1: radioButton8.Checked = true; break;
            }
            textBox2.Text = ifClassBuf.MessageString;    //上記条件に当てはまった時のメッセージ
            for(int a = 0; a<comboBox1.Items.Count; a++){
                if(comboBox1.Items[a].ToString()==ifClassBuf.MessageColor){
                    comboBox1.SelectedIndex = a;
                    break;
                }
            }
            for(int a = 0; a<comboBox2.Items.Count; a++){
                if(comboBox2.Items[a].ToString()==ifClassBuf.CmdName){
                    comboBox2.SelectedIndex = a;
                    break;
                }
            }
            textBox3.Text = ifClassBuf.StopTimer.ToString();
            //与えられた番号によりマスクする
            switch (JyokenNo)
            {
                case 0://起動前条件
                    groupBox3.Text += "(必ず設定してください)"; 
                    break;
                case 1://終了条件
                    groupBox3.Text += "(記入しなくてもOK)";
                    break;
                case 2://エラー条件
                    groupBox3.Text += "(記入しなくてもOK)";
                    break;
                case 3://継続条件
                    groupBox3.Text += "(必ず設定してください)";
                    break;
                case 4://メッセージ表示条件
                    groupBox3.Visible = false;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ifClassBuf.HyoujiName = textBox1.Text;

            if (radioButton1.Checked) ifClassBuf.RunRule = 0;
            else if (radioButton2.Checked) ifClassBuf.RunRule = 1;
            else if (radioButton3.Checked) ifClassBuf.RunRule = 2;

            if (radioButton4.Checked) ifClassBuf.UnitRowNo = 0;
            else if (radioButton5.Checked) ifClassBuf.UnitRowNo = 1;
            else if (radioButton6.Checked) ifClassBuf.UnitRowNo = 2;

            if (radioButton7.Checked) ifClassBuf.EndWaitRule = 0;
            else if (radioButton8.Checked) ifClassBuf.EndWaitRule = 1;

            ifClassBuf.MessageString = textBox2.Text;    //上記条件に当てはまった時のメッセージ
            if (comboBox1.SelectedIndex == -1) ifClassBuf.MessageColor = "";
            else ifClassBuf.MessageColor = comboBox1.Items[comboBox1.SelectedIndex].ToString();

            if (comboBox2.SelectedIndex == -1) ifClassBuf.CmdName = "";
            else ifClassBuf.CmdName = comboBox2.Items[comboBox2.SelectedIndex].ToString();
            
            Int32.TryParse( textBox3.Text, out ifClassBuf.StopTimer);

            DialogResult = DialogResult.OK;
        }
        //追加
        private void button7_Click(object sender, EventArgs e)
        {
            IfStatusInfo p = new IfStatusInfo();

            SettingForm3 dlg = new SettingForm3(OwnerP, p);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                ifClassBuf.StatusInfoList.Add(dlg.data);
                listBox2.Items.Add(dlg.NameStr);
                listBox2.SelectedIndex = listBox2.Items.Count - 1;
            }
        }
        //削除
        private void button8_Click(object sender, EventArgs e)
        {
            int sel = listBox2.SelectedIndex;
            if (sel < 0) return;

            ifClassBuf.StatusInfoList.RemoveAt(sel);
            listBox2.Items.RemoveAt(sel);
        }
        //編集
        private void button9_Click(object sender, EventArgs e)
        {
            int sel = listBox2.SelectedIndex;
            if (sel < 0) return;
            IfStatusInfo p = ifClassBuf.StatusInfoList[sel];

            SettingForm3 dlg = new SettingForm3(OwnerP, p);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                ifClassBuf.StatusInfoList[sel] = dlg.data;
                listBox2.Items[sel] = (object)dlg.NameStr;
            }
        }

        private void listBox2_DoubleClick(object sender, EventArgs e)
        {
            button9_Click(sender, e);
        }
    }
}
