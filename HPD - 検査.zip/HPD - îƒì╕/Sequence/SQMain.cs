﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using System.Threading;
using System.IO.Ports;
using System.Runtime.InteropServices;

//「機種毎に変更必要」と書かれている部分を修正のこと
namespace Simulator
{
    public partial class SQMain : Form
    {

        /// <summary>
        /// 装置機からの戻り値
        /// </summary>
        private string _return = "OK";

        //オーナーフォーム
        Form OwnerForm = null;

        //アドレスNo
        String Address = "";
        //アドレスNo
        SgNet.COM.File_s.IniFile_s SettingIni = null;
        //ロット
        String Lot = "";
        //号機
        String SID = "";
        //予備１
        String Yobi1 = "";
        //予備２
        String Yobi2 = "";
        //ユニット
        private String Unit = "";
        //言語
        public String Lang = "";

        //エージング２の回数を格納する変数
        public String Aging2times = "";

        //CmdFormを終了させるフラグ
        bool EndFlg = false;

        //前回実行コマンド
        Cmd BeforeCmd = null;

        //強制停止用フラグ
        public bool ForceStopFlg = false;

        //コマンド実行スレッド
        public System.Threading.Thread MainThread1 = null;
        public System.Threading.Thread MainThread2 = null;
        public System.Threading.Thread MainThread3 = null;
        public System.Threading.Thread CompWaitThread = null;

        public int ThreadStatus1 = 0; //1=動作中  0=完了 -1=エラー
        public int ThreadStatus2 = 0; //1=動作中  0=完了 -1=エラー 
        public int ThreadStatus3 = 0; //1=動作中  0=完了 -1=エラー

        //前回実行時のタスクリスト　マルチライン用
        public List<PatternRow> BeforeList = null;

        //前回実行時のカーソル行　　マルチライン用
        public int NowRow = 0;

        //前回実行時のカーソル列　　マルチライン用
        public int NowCol = 0;
        
        //通信セット
        private SgNet.COM.Comm_s.Sio_s SioP = null;
        private List<byte[]> RecvData = new List<byte[]>();
        private List<int> RecvInfo = new List<int>();
        private byte[] RecvDataBuf = new byte[65536];
        private int RecvDataSize = -1;

        //タイムアウト用タイマー
        System.Threading.TimerCallback TimeOutEvent;
        System.Threading.Timer TimeOutTimer;
        int TimeOutTime = 1000;

        /// <summary>
        /// オープンフラグ
        /// </summary>
        public bool OpenFlg = false;

        public struct RecvResult
        {
            public bool Result;
            public byte[] Recv;
            public RecvResult(bool result, byte[] recv)
            {
                Result = result;
                Recv = recv;
            }
        }

        //***********************************************************************************************
        #region GUIからの指示
        //***********************************************************************************************

        /// <summary>
        /// コンストラクタ 
        /// </summary>
        /// <param name="ownerForm">オーナーフォーム</param>
        /// <param name="address">起動時のアドレス　必要に応じて使用</param>
        /// <param name="iniP">Settings.iniを読み込んだIniFile_sクラスオブジェクト</param>
        /// <param name="lot">ロット</param>
        /// <param name="sID">号機</param>
        /// <param name="unit">号機</param>
        /// <param name="Lang">言語</param>
        public SQMain(Form ownerForm, String address, SgNet.COM.File_s.IniFile_s iniP, String lot, String sID, String unit, String language)
        {
            OwnerForm = ownerForm;
            Address = address;
            SettingIni = iniP;
            Lot = lot;
            SID = sID;
            Unit = unit;
            Lang = language;
            InitializeComponent();
        }
        /// <summary>
        /// コンストラクタ 
        /// </summary>
        /// <param name="ownerForm">オーナーフォーム</param>
        /// <param name="address">起動時のアドレス　必要に応じて使用</param>
        /// <param name="iniP">Settings.iniを読み込んだIniFile_sクラスオブジェクト</param>
        /// <param name="lot">ロット</param>
        /// <param name="sID">号機</param>
        /// <param name="sID">言語</param>
        /// <param name="yobi1">予備1</param>
        public SQMain(Form ownerForm, String address, SgNet.COM.File_s.IniFile_s iniP, String lot, String sID, String unit, String language, String yobi1)
        {
            OwnerForm = ownerForm;
            Address = address;
            SettingIni = iniP;
            Lot = lot;
            SID = sID;
            Unit = unit;
            Lang = language;
            Yobi1 = yobi1;
            InitializeComponent();
        }

        /// <summary>
        /// コンストラクタ 
        /// </summary>
        /// <param name="ownerForm">オーナーフォーム</param>
        /// <param name="address">起動時のアドレス　必要に応じて使用</param>
        /// <param name="iniP">Settings.iniを読み込んだIniFile_sクラスオブジェクト</param>
        /// <param name="lot">ロット</param>
        /// <param name="sID">号機</param>
        /// <param name="sID">言語</param>
        /// <param name="yobi1">予備1</param>
        /// <param name="yobi2">予備2</param>
        public SQMain(Form ownerForm, String address, SgNet.COM.File_s.IniFile_s iniP, String lot, String sID, String unit, String language, String yobi1, String yobi2)
        {
            OwnerForm = ownerForm;
            Address = address;
            SettingIni = iniP;
            Lot = lot;
            SID = sID;
            Unit = unit;
            Lang = language;
            Yobi1 = yobi1;
            Yobi2 = yobi2;
            InitializeComponent();
        }

        //フォームロード
        private void SQMain_Load(object sender, EventArgs e)
        {
            //this.OpenSerialPort();

            //機種毎に変更必要********
            //通信のオープン ※ 9600bps・パリティ=even・データ長=7・ストップ=1
            SioOpen(Address, 9600, System.IO.Ports.Parity.Even, 7, System.IO.Ports.StopBits.One);
            //入出金データ通信のオープン ※ 115200bps・パリティ=none・データ長=8・ストップ=1
            SgNet.COM.File_s.IniFile_s RecvSetIni = new SgNet.COM.File_s.IniFile_s(Application.StartupPath + "\\RecvSettings.ini");
            string RecvAdd = RecvSetIni.ReadString("Settings", "Address", "");
            SioRecvOpen(RecvAdd, 115200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);

            SetErrorData();                     //エラー名ファイルの読み込み
            //************************
            if (OwnerForm != null)
            {
                this.Location = OwnerForm.Location;
            }
        }

        /// <summary>
        /// FormDispose(アプリケーション終了時に必ず実施のこと)
        /// </summary>
        public void FormDispose()
        {
            EndFlg = true;
            ForceStop();

            //スリープ
            SgNet.COM.Time_s.Sleep(50);

            //通信の削除
            SioClose();
            SioRecvClose();

            //スリープ
            SgNet.COM.Time_s.Sleep(50);

            this.Close();
        }

        /// <summary>
        /// FormのShow
        /// </summary>
        public void FormShow()
        {
            this.Location = OwnerForm.Location;
            this.Hide();
            this.Show();
        }

        /// <summary>
        /// PLCと通信するシリアルポードをオープンする。
        /// </summary>
        //private void OpenSerialPort()
        //{
        //    this._serialPort.BaudRate = 9600;
        //    this._serialPort.Parity = Parity.None;
        //    this._serialPort.DataBits = 8;
        //    this._serialPort.StopBits = StopBits.One;
        //    this._serialPort.Handshake = Handshake.None;
        //    var fPath = System.IO.Path.Combine(Application.StartupPath, "Communication.ini");
        //    var com = GetIniValue(fPath, "Settings", "RobotComNo");
        //    this._serialPort.PortName = com; //暫定
        //    if (this._serialPort.IsOpen == false)
        //    {
        //        this._serialPort.Open();
        //    }
        //}

        //private void CloseSerialPort()
        //{
        //    if (this._serialPort.IsOpen == true)
        //    {
        //        this._serialPort.Close();
        //    }
        //}
        /// <summary>
        /// 品証ツールなどのまとめてコマンド実行
        /// </summary>
        /// <param name="cmd">実行コマンド</param>
        /// <param name="list">実行時のTasksリスト</param>
        /// <param name="nowRow">実行時のカーソル行　0～</param>
        /// <param name="nowCol">実行時のカーソル列　0～</param>
        /// <returns>OK=true/NG=false</returns>
        public bool StartCmd(Cmd cmd, List<PatternRow> list, int nowRow, int nowCol)
        {
            BeforeList = list;
            NowRow = nowRow;
            NowCol = nowCol;
            System.IO.File.AppendAllText(@"C:\test.txt", "Start(cmd)");
            return Start(cmd);
        }

        /// <summary>
        /// PLC(ロボット制御)と通信
        /// </summary>
        /// <param name="pattern"></param>
        //private void RobotThread(object pattern)
        //{
        //    //this.OpenSerialPort();
        //    var pat = (string)pattern;

        //    var sendData = new byte[3];
        //    sendData[0] = 2;  //テキスト開始(STX)
        //    sendData[2] = 3;　//テキスト終了(ETX)　
        //    switch (pat)
        //    {
        //        case "Syukkin":
        //            sendData[1] = 20;  //テキスト内容
        //            break;
        //        case "Nyukin":
        //            sendData[1] = 30;
        //            break;
        //        case "Syukkin2000":
        //            sendData[1] = 40;
        //            break;
        //        case "Syukkin999":
        //            sendData[1] = 60;
        //            break;
        //        case "ZenNyukin":
        //            sendData[1] = 70;
        //            break;
        //        default:
        //            break;
        //    }
        //    this._serialPort.Write(sendData, 0, 3);
        //    Thread.Sleep(1000);

        //    sendData[1] = 10;
        //    this._serialPort.Write(sendData, 0, 3);  //データ送信

        //    this.CloseSerialPort();
        //}

        /// <summary>
        /// 開始の処理
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        private bool Start(Cmd cmd)
        {
            while (this._return == "NG")
            {
                SgNet.COM.Time_s.Sleep(10);
            }
            //機種毎に変更必要**************
            //コマンド間のスリープ
            SgNet.COM.Time_s.Sleep(10);     //検討の必要ある？送信長は１０バイト程度（１０ｍｓ）より長い
            //******************************
            GC.Collect();

            ForceStopFlg = false;
            BeforeCmd = cmd;

            //ポートがオープンしているかどうかを確認
            if (!OpenFlg) return false;

            //現在実行中か確認
            if (CompWaitThread != null ||
                MainThread1 != null ||
                MainThread2 != null ||
                MainThread3 != null) return false;

            //コマンドパターンにより分岐⇒送信＆受信待ちスレッド起動
            switch (cmd.FileName)
            {
                //機種毎に変更必要********

                //動作スレッドについて
                //終了させるにはThreadStatus1を 0=完了 or -1=エラーに変化させ、MainThread1をnullにする

                //各コマンドの記載
                case "Reset":
                    ThreadStatus1 = 1;//動作中にする
                    Reset cmdReset = new Reset(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdReset.MainFunc);//動作スレッドの起動
                    break;
                case "Aging":
                    ThreadStatus1 = 1;//動作中にする
                    Aging cmdAging = new Aging(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdAging.MainFunc);//動作スレッドの起動
                    break;
                case "Aging2":
                    ThreadStatus1 = 1;//動作中にする
                    Aging2 cmdAging2 = new Aging2(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdAging2.MainFunc);//動作スレッドの起動
                    break;
                case "DateTimeSet":
                    ThreadStatus1 = 1;//動作中にする
                    DateTimeSet cmdDateTimeSet = new DateTimeSet(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdDateTimeSet.MainFunc);//動作スレッドの起動
                    break;
                case "Nyukin":
                    ThreadStatus1 = 1;//動作中にする
                    Nyukin cmdNyukin = new Nyukin(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdNyukin.MainFunc);//動作スレッドの起動
                    break;
                case "Syukkin":
                    ThreadStatus1 = 1;//動作中にする
                    Syukkin cmdSyukkin = new Syukkin(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdSyukkin.MainFunc);//動作スレッドの起動
                    break;
                case "KaisyuPAYOUT":
                    ThreadStatus1 = 1;//動作中にする
                    KaisyuPAYOUT cmdKaisyuPAYOUT = new KaisyuPAYOUT(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdKaisyuPAYOUT.MainFunc);//動作スレッドの起動
                    break;
                case "KaisyuCST1":
                    ThreadStatus1 = 1;//動作中にする
                    KaisyuCST1 cmdKaisyuCST1 = new KaisyuCST1(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdKaisyuCST1.MainFunc);//動作スレッドの起動
                    break;
                case "KaisyuCST3":
                    ThreadStatus1 = 1;//動作中にする
                    KaisyuCST3 cmdKaisyuCST3 = new KaisyuCST3(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdKaisyuCST3.MainFunc);//動作スレッドの起動
                    break;
                case "NyukinEnd":
                    ThreadStatus1 = 1;//動作中にする
                    NyukinEnd cmdNyukinEnd = new NyukinEnd(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdNyukinEnd.MainFunc);//動作スレッドの起動
                    break;
                case "Logread":
                    ThreadStatus1 = 1;//動作中にする
                    Logread cmdLogread = new Logread(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdLogread.MainFunc);//動作スレッドの起動
                    break;
                case "Unitinfo":
                    ThreadStatus1 = 1;//動作中にする
                    Unitinfo cmdUnitinfo = new Unitinfo(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdUnitinfo.MainFunc);//動作スレッドの起動
                    break;
                case "Sensadj":
                    ThreadStatus1 = 1;//動作中にする
                    Sensadj cmdSensadj = new Sensadj(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdSensadj.MainFunc);//動作スレッドの起動
                    break;
                case "Initset":
                    ThreadStatus1 = 1;//動作中にする
                    Initset cmdInitset = new Initset(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdInitset.MainFunc);//動作スレッドの起動
                    break;
                case "Honkenset":
                    ThreadStatus1 = 1;//動作中にする
                    Honkenset cmdHonkenset = new Honkenset(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdHonkenset.MainFunc);//動作スレッドの起動
                    break;
                case "Dummyset":
                    ThreadStatus1 = 1;//動作中にする
                    Dummyset cmdDummyset = new Dummyset(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdDummyset.MainFunc);//動作スレッドの起動
                    break;
                case "Manualfillset":
                    ThreadStatus1 = 1;//動作中にする
                    Manualfillset cmdManualfillset = new Manualfillset(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdManualfillset.MainFunc);//動作スレッドの起動
                    break;
                case "SenscheckSTD":
                    ThreadStatus1 = 1;//動作中にする
                    SenscheckSTD cmdSenscheckSTD = new SenscheckSTD(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdSenscheckSTD.MainFunc);//動作スレッドの起動
                    break;
                case "SenscheckASS":
                    ThreadStatus1 = 1;//動作中にする
                    SenscheckASS cmdSenscheckASS = new SenscheckASS(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdSenscheckASS.MainFunc);//動作スレッドの起動
                    break;
                case "SenscheckTEST":
                    ThreadStatus1 = 1;//動作中にする
                    SenscheckTEST cmdSenscheckTEST = new SenscheckTEST(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdSenscheckTEST.MainFunc);//動作スレッドの起動
                    break;
                case "SenscheckDUST":
                    ThreadStatus1 = 1;//動作中にする
                    SenscheckDUST cmdSenscheckDUST = new SenscheckDUST(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdSenscheckDUST.MainFunc);//動作スレッドの起動
                    break;
                case "Portread":
                    ThreadStatus1 = 1;//動作中にする
                    Portread cmdPortread = new Portread(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdPortread.MainFunc);//動作スレッドの起動
                    break;
                case "Interlock":
                    ThreadStatus1 = 1;//動作中にする
                    Interlock cmdInterlock = new Interlock(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdInterlock.MainFunc);//動作スレッドの起動
                    break;
                case "Keycheck":
                    ThreadStatus1 = 1;//動作中にする
                    Keycheck cmdKeycheck = new Keycheck(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdKeycheck.MainFunc);//動作スレッドの起動
                    break;
                case "LEDcheck":
                    ThreadStatus1 = 1;//動作中にする
                    LEDcheck cmdLEDcheck = new LEDcheck(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdLEDcheck.MainFunc);//動作スレッドの起動
                    break;
                case "BVsenschk":
                    ThreadStatus1 = 1;//動作中にする
                    BVsenschk cmdBVsenschk = new BVsenschk(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdBVsenschk.MainFunc);//動作スレッドの起動
                    break;
                case "Logclear":
                    ThreadStatus1 = 1;//動作中にする
                    Logclear cmdLogclear = new Logclear(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdLogclear.MainFunc);//動作スレッドの起動
                    break;
                case "CassetteIC":
                    ThreadStatus1 = 1;//動作中にする
                    CassetteIC cmdCassetteIC = new CassetteIC(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdCassetteIC.MainFunc);//動作スレッドの起動
                    break;
                case "Movecheck":
                    ThreadStatus1 = 1;//動作中にする
                    Movecheck cmdMovecheck = new Movecheck(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdMovecheck.MainFunc);//動作スレッドの起動
                    break;
                case "Empsenscheck":
                    ThreadStatus1 = 1;//動作中にする
                    Empsenscheck cmdEmpsenscheck = new Empsenscheck(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdEmpsenscheck.MainFunc);//動作スレッドの起動
                    break;
                case "Cassettepopup":
                    ThreadStatus1 = 1;//動作中にする
                    Cassettepopup cmdCassettepopup = new Cassettepopup(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdCassettepopup.MainFunc);//動作スレッドの起動
                    break;
                case "Cassette1OUT":
                    ThreadStatus1 = 1;//動作中にする
                    Cassette1OUT cmdCassette1OUT = new Cassette1OUT(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdCassette1OUT.MainFunc);//動作スレッドの起動
                    break;
                case "Cassette2OUT":
                    ThreadStatus1 = 1;//動作中にする
                    Cassette2OUT cmdCassette2OUT = new Cassette2OUT(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdCassette2OUT.MainFunc);//動作スレッドの起動
                    break;
                case "Cassette3OUT":
                    ThreadStatus1 = 1;//動作中にする
                    Cassette3OUT cmdCassette3OUT = new Cassette3OUT(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdCassette3OUT.MainFunc);//動作スレッドの起動
                    break;
                case "Cassette3insert":
                    ThreadStatus1 = 1;//動作中にする
                    Cassette3insert cmdCassette3insert = new Cassette3insert(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdCassette3insert.MainFunc);//動作スレッドの起動
                    break;
                case "RasEnd":
                    ThreadStatus1 = 1;//動作中にする
                    RasEnd cmdRasEnd = new RasEnd(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdRasEnd.MainFunc);//動作スレッドの起動
                    break;
                case "Rasstop":
                    ThreadStatus1 = 1;//動作中にする
                    Rasstop cmdRasstop = new Rasstop(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdRasstop.MainFunc);//動作スレッドの起動
                    break;
                case "RJLockRel":
                    ThreadStatus1 = 1;//動作中にする
                    RJLockRel cmdRJLockRel = new RJLockRel(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdRJLockRel.MainFunc);//動作スレッドの起動
                    break;
                case "NempChkSyukkin":
                    ThreadStatus1 = 1;//動作中にする
                    NempChkSyukkin cmdNempChkSyukkin = new NempChkSyukkin(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdNempChkSyukkin.MainFunc);//
                    break;
                case "FullSyukkin":
                    ThreadStatus1 = 1;//動作中にする
                    FullSyukkin cmdFullSyukkin = new FullSyukkin(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdFullSyukkin.MainFunc);//動作スレッドの起動
                    break;
                case "Stage3move":
                    ThreadStatus1 = 1;//動作中にする
                    Stage3move cmdStage3move = new Stage3move(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdStage3move.MainFunc);//動作スレッドの起動
                    break;
                case "Sens17adjust":
                    ThreadStatus1 = 1;//動作中にする
                    Sens17adjust cmdSens17adjust = new Sens17adjust(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdSens17adjust.MainFunc);//動作スレッドの起動
                    break;
                case "SensCondition":
                    ThreadStatus1 = 1;//動作中にする
                    SensCondition cmdSensCondition = new SensCondition(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdSensCondition.MainFunc);//動作スレッドの起動
                    break;
                case "Modoshiire":
                    ThreadStatus1 = 1;//動作中にする
                    Modoshiire cmdModoshiire = new Modoshiire(cmd, this, 1);//処理クラスのnew
                    MainThread1 = SgNet.COM.Thread_s.Start(cmdModoshiire.MainFunc);//動作スレッドの起動
                    break;
                case "ChangeAddress":
                    break;

                //************************
                default://存在しないコマンド
                    return false;
            }
            if (MainThread1 != null || MainThread2 != null || MainThread3 != null)
            {
                //終了待ちスレッドの起動
                CompWaitThread = SgNet.COM.Thread_s.Start(EndWaitThread);
            }
            return true;
        }

        private void EndWaitThread()
        {
            while (true)
            {
                if (ForceStopFlg == true)
                {
                    break;
                }
                if (MainThread1 == null && MainThread2 == null && MainThread3 == null)
                {
                    //終了　状態は子クラスから通知される（１：動作中　０：正常終了　－１：異常終了）
                    if (ThreadStatus1 == 0 && ThreadStatus2 == 0 && ThreadStatus3 == 0)     //正常
                    {
                        CompWaitThread = null; //次のNotifyCompleteですぐに来てしまうのでここでnullにする
                        //機種毎に修正要
                        if (Aging2times != "")
                        {
                            NotifyComplete(false, Aging2times); //OK NGに加えて値を返す場合
                            Aging2times = "";
                        }
                        else if (BeforeCmd.FileName == "DateTimeSet")
                        {
                            NotifyComplete(false, "DateTimeSet"); //OK NGに加えて値を返す場合
                        }
                        else
                        {
                            NotifyComplete(false, "");          //OK NGだけを返す場合
                        }
                        //NotifyComplete(BeforeList);  //OK NGを修正したBeforeListを返す場合
                    }
                    else     //異常
                    {
                        CompWaitThread = null; //次のNotifyCompleteですぐに来てしまうのでここでnullにする
                        //機種毎に修正要
                        if (Aging2times != "")
                        {
                            NotifyComplete(true, Aging2times);  //OK NGに加えて値を返す場合
                            Aging2times = "";
                        }
                        else
                        {
                            NotifyComplete(true, "");           //OK NGだけを返す場合
                        }
                        //NotifyComplete(BeforeList); //OK NGを修正したBeforeListを返す場合
                    }
                    break;
                }
                SgNet.COM.Time_s.Sleep(5);
            }
            CompWaitThread = null;
        }
        /// <summary>
        /// 強制停止
        /// </summary>
        /// <returns>OK=true/NG=false</returns>
        public bool ForceStop()
        {
            if (CompWaitThread == null &&
                MainThread1 == null &&
                MainThread2 == null &&
                MainThread3 == null) return true;

            ForceStopFlg = true;

            //必要に応じてスリープ
            SgNet.COM.Time_s.Sleep(100);
            if (CompWaitThread == null &&
                MainThread1 == null &&
                MainThread2 == null &&
                MainThread3 == null) return true;

            if (CompWaitThread != null)
            {
                try
                {
                    SgNet.COM.Thread_s.Abort(CompWaitThread);
                    CompWaitThread = null;
                    return true;
                }
                catch
                {
                    CompWaitThread = null;
                }
            }
            if (MainThread1 != null)
            {
                try
                {
                    SgNet.COM.Thread_s.Abort(MainThread1);
                    MainThread1 = null;
                    return true;
                }
                catch
                {
                    MainThread1 = null;
                }
            }
            if (MainThread2 != null)
            {
                try
                {
                    SgNet.COM.Thread_s.Abort(MainThread2);
                    MainThread2 = null;
                    return true;
                }
                catch
                {
                    MainThread2 = null;
                }
            }
            if (MainThread3 != null)
            {
                try
                {
                    SgNet.COM.Thread_s.Abort(MainThread3);
                    MainThread3 = null;
                    return true;
                }
                catch
                {
                    MainThread3 = null;
                }
            }
            return false;
        }

        #endregion GUIからの指示
        //***********************************************************************************************

        //***********************************************************************************************
        #region GUIへの通知

        //デリゲート宣言****************
        //GUIの各種情報変更通知
        public delegate void DelegateChangeInfo(int unitNo, int idNo, String infoString, Color labelColor);
        //GUIのフォームの色を変える
        public delegate void DelegateChangeFormColor(Color formColor);
        //GUIへの枚数変更通知
        public delegate void DelegateChangeMaisu(List<int> maisu, int rowNo);
        //GUIへの完了通知
        public delegate void DelegateNotifyComplete(bool erroFlg, String value);
        //GUIへの完了通知 複数行
        public delegate void DelegateNotifyCompleteMultiLine(List<PatternRow> list);
        //GUIへのプログレスバー変更通知
        public delegate void DelegateChangeProgressBar(uint max, uint val);

        //イベントの宣言****************
        public event DelegateChangeInfo ChangeInfoEvent;
        public event DelegateChangeFormColor ChangeFormColorEvent;
        public event DelegateChangeMaisu ChangeMaisuEvent;
        public event DelegateNotifyComplete NotifyCompleteEvent;
        public event DelegateNotifyCompleteMultiLine NotifyCompleteMultiLineEvent;
        public event DelegateChangeProgressBar ChangeProgressBarEvent;

        /// <summary>
        /// GUIにラベルやフォームの状態を通知
        /// </summary>
        /// <param name="unitNo"></param>
        /// <param name="idNo"></param>
        /// <param name="infoString"></param>
        /// <param name="labelColor"></param>
        public void ChangeInfo(int unitNo, int idNo, String infoString, Color labelColor)
        {
            try
            {
                ChangeInfoEvent(unitNo, idNo, infoString, labelColor);
            }
            catch { }
        }
        /// <summary>
        /// GUIのフォームの色を変える
        /// </summary>
        /// <param name="formColor"></param>
        public void ChangeFormColor(Color formColor)
        {
            try
            {
                ChangeFormColorEvent(formColor);
            }
            catch { }
        }
        /// <summary>
        /// GUIに枚数を通知
        /// </summary>
        /// <param name="maisu"></param>
        /// <param name="rowNo"></param>
        public void ChangeMaisu(List<int> maisu, int rowNo)
        {
            try
            {
                ChangeMaisuEvent(maisu, rowNo);
            }
            catch { }
        }
        /// <summary>
        /// GUIに完了（エラー通知）を通知
        /// </summary>
        /// <param name="erroFlg"></param>
        public void NotifyComplete(bool erroFlg, String value)
        {
            try
            {
                NotifyCompleteEvent(erroFlg, value);
            }
            catch { }
        }

        /// <summary>
        /// GUIに完了（エラー通知）を通知　複数行
        /// </summary>
        /// <param name="erroFlg"></param>
        public void NotifyCompleteMultiLine(List<PatternRow> list)
        {
            try
            {
                NotifyCompleteMultiLineEvent(list);
            }
            catch { }
        }

        /// <summary>
        /// GUIにダウンロードなどのプログレスバーの進行状況を通知
        /// </summary>
        /// <param name="max"></param>
        /// <param name="val"></param>
        public void ChangeProgressBar(uint max, uint val)
        {
            try
            {
                ChangeProgressBarEvent(max, val);
            }
            catch { }
        }
        #endregion GUIへの通知
        //***********************************************************************************************


        //***********************************************************************************************
        #region フォーム固有の共有関数


        //フォームを閉じるとき
        private void CmdForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!EndFlg)
            {
                this.Hide();
                e.Cancel = true;
            }
        }

        /// <summary>
        /// ログに文字列を追加
        /// </summary>
        /// <param name="str">追加する文字列</param>
        public void AddList(String str)
        {
            String ss = "";
            ss += SgNet.COM.Time_s.DateTimeMSec() + " : " + str;
            listBox1.Items.Add(ss);
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        /// <summary>
        /// リストボックスに文字列追加
        /// </summary>
        /// <param name="data">追加したいバイト配列</param>
        /// <param name="sendFlg">送信フラグ</param>
        public void AddList(byte[] data, bool sendFlg)
        {
            AddList(data, data.Length, sendFlg);
        }

        /// <summary>
        /// リストボックスに文字列追加
        /// </summary>
        /// <param name="data">追加したいバイト配列</param>
        /// <param name="size">送信サイズ</param>
        /// <param name="sendFlg">送信フラグ</param>
        private void AddList(byte[] data, int size, bool sendFlg)
        {
            String str = "";
            String str2 = "";
            //機種毎に変更必要   コメントアウトするとそのまま出力されます
            int len = 2048;
            if (size > len)
            {
                str2 += "xxx(Total=" + size.ToString() + " byte)";
            }
            else
            //********************
            {
                len = size;
            }
            if (data != null)
            {
                for (int a = 0; a < size; a++)
                {
                    str += data[a].ToString("X02") + " ";
                }
            }
            String ss = "";
            ss += SgNet.COM.Time_s.DateTimeMSec() + (sendFlg ? " > " : " < ") + str + str2;
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                listBox1.Items.Add(ss);
                listBox1.SelectedIndex = listBox1.Items.Count - 1;
            });
        }

        //ログの保存
        private void button1_Click(object sender, EventArgs e)
        {
            //保存先の取得
            String path = SgNet.COM.File_s.SaveDialog("Text File|*.txt;*.txt");
            if (path == "") return;

            //書込み文字列取得
            List<String> list = new List<String>();
            for (int a = 0; a < listBox1.Items.Count; a++)
            {
                list.Add(listBox1.Items[a].ToString());
            }

            //ファイルへ保存
            if (SgNet.COM.File_s.Text_s.WriteFileAllFromFile(path, list) == true)
            {
                switch (Lang)
                {
                    case "CN":
                        SgNet.COM.MessageBox_s.ShowInfomation(Application.StartupPath + "\\MsgStringC.ini", "Msg", "1", "Complete");
                        break;
                    case "JP":
                        SgNet.COM.MessageBox_s.ShowInfomation(Application.StartupPath + "\\MsgStringJ.ini", "Msg", "1", "Complete");
                        break;
                }
            }
            else
            {
                switch (Lang)
                {
                    case "CN":
                        SgNet.COM.MessageBox_s.ShowInfomation(Application.StartupPath + "\\MsgStringC.ini", "Msg", "2", "False!");
                        break;
                    case "JP":
                        SgNet.COM.MessageBox_s.ShowInfomation(Application.StartupPath + "\\MsgStringJ.ini", "Msg", "2", "False!");
                        break;
                }
            }
            GC.Collect();
        }

        #endregion フォーム固有の共有関数
        //***********************************************************************************************

        //***********************************************************************************************
        #region 通信処理

        /// <summary>
        /// オープン
        /// </summary>
        /// <param name="ComName">COM名　例："COM1"</param>
        /// <param name="boudrate">ボーレート</param>
        /// <param name="parity">パリティ</param>
        /// <param name="dataLen">データ長</param>
        /// <param name="stopbits">ストップビット</param>
        public void SioOpen(String ComName, int boudrate, System.IO.Ports.Parity parity, int dataLen, System.IO.Ports.StopBits stopbits)
        {
            //COMポートのオープン
            try
            {
                //開く
                SioP = new SgNet.COM.Comm_s.Sio_s(ComName, boudrate, parity, dataLen, stopbits);
                SioP.RecvEventFunc += new SgNet.COM.Comm_s.Sio_s.RecvEvent(this.RecvEvent);

                //タイムアウト用のイベント追加
                TimeOutEvent = new System.Threading.TimerCallback(TimeOutClock);
                TimeOutTimer = new System.Threading.Timer(TimeOutEvent, null, -1, -1);
                OpenFlg = true;
                return;
            }
            catch (Exception e)
            {
                MessageBox.Show(this, e.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        //ポートのクローズ
        private bool SioClose()
        {
            //閉じる
            if (SioP != null)
            {
                SioP.Dispose();
                SioP = null;
            }
            return true;
        }


        //追加箇所   ***********************************************
        //コマンド定義のenum
        public enum CmdCode
        {
            //11H~17H
            RASsense = 17, RASstart, RASend, RASstop, RASsinglemove, RASmovecheck, RASsenscheck,
            //18H~1FH
            RASportread, RASsensadj, RASsensread, RASsenslevel, RASBVsensadj, RASBVsensread, RASmemclear, RASrefill,
            //20H~26H
            RASLEDctrl, RASICinit, RASICcheck, RASsenscond, RASBVsensinfo, RASPayoutsensread, RASAging2,
            //30H~37H
            Reset = 48, PayoutAmount, Examine, AmountdataCorrect, Memread, PayoutPieces, OutBills, DateTimeSet,
            //38H~3FH
            BillCollection, PayoutGetPcs, AmountClear, ConditionRead, LogClear, LogRead, SetSWRead, SetSWWrite,
            //40H~48H
            ExpandMemread, CountdataRead, ERRrecCountStart, ERRrecPayout, CountReturn, CountStart, CountEnd, CountStop, CountResume,
            //4AH~60H
            DownloadMode = 74, Verread, Aging = 77, LockRelease = 80, Refill = 83, Modoshiire = 87, Refilldataread = 94, RefillStart = 96,
            //61H~65H
            ICInfoSend, ICInfoWrite, ICInfoRead, PayoutWaitCancel = 101
        }

        //制御文字のenum
        public enum CtrlChar
        {
            NUL, SOH, STX, ETX, EOT, ENQ, ACK, BEL, BS, HT, LF, VT, FF, CR, SO, SI,
            DLE, DC1, DC2, DC3, DC4, NAK, SYN, ETB, CAN, EM, SUB, ESC, FS, GS, RS, US
        }

        //コマンド生成（データがないもの）
        public byte[] MakeSendData(byte commandNO)
        {
            byte[] data = new byte[7];

            data[0] = (byte)CtrlChar.STX;           //STX
            data[1] = (byte)CtrlChar.DC1;           //DC1
            data[2] = commandNO;                    //コマンド
            data[3] = 0x30;                         //L(16^1)
            data[4] = 0x30;                         //L(16^0)
            data[5] = (byte)CtrlChar.ETX;           //ETX
            data[6] = 0x00;                         //BCC初期化
            for (int i = 1; i < 6; i++)
            {
                data[6] ^= data[i];                 //BCCを求める
            }
            AddParity(data);
            return data;
        }

        //コマンド生成（データがあるもの）（コマンド番号,データ長,データ部配列）
        public byte[] MakeSendData(byte commandNO, int length, byte[] dt)
        {
            byte[] data = new byte[7 + length];

            data[0] = (byte)CtrlChar.STX;           //STX
            data[1] = (byte)CtrlChar.DC1;           //DC1
            data[2] = commandNO;                    //コマンド
            data[3] = (byte)(0x30 | (length / 16)); //L(16^1)
            data[4] = (byte)(0x30 | (length % 16)); //L(16^0)

            for (int d = 0; d < length; d++)
            {
                data[5 + d] = dt[d];                //データ部代入
            }
            data[5 + length] = (byte)CtrlChar.ETX;  //ETX
            data[6 + length] = 0x00;                //BCC初期化
            for (int i = 1; i < (6 + length); i++)
            {
                data[6 + length] ^= data[i];        //BCCを求める
            }
            AddParity(data);
            return data;
        }

        //制御文字のみをコマンドとするもの
        public byte[] MakeSingleChar(byte charcter)
        {
            byte[] data = new byte[1];
            data[0] = charcter;
            AddParity(data);
            return data;
        }

        //パリティビットが０になるか１になるかの表
        static byte[] parityVal = {
            0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,     //  0~ 15
            1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,     // 16~ 31
            1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,     // 32~ 47
            0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,     // 48~ 63
            1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,     // 64~ 79
            0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,     // 80~ 95
            0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,     // 96~111
            1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1      //112~127
        };
        //パリティビット付加
        public void AddParity(byte[] data)
        {
            for (int i = 0; i < data.Length; i++)
            {
                //data[i]の値（0～127）に従って上の表を参照する（１だったらパリティも１にする）
                if (parityVal[data[i]] == 1)
                {
                    data[i] |= 0x80;
                }
            }
        }

        public void dispclear()
        {
            ChangeInfo(0, 0, " ", System.Drawing.Color.White);
            ChangeInfo(0, 1, " ", System.Drawing.Color.White);
        }

        //レスポンスチェック・制御文字のみ（受信データ,ENQ待ち要否）　戻り値：エラー有無
        public bool RespCheck(byte[] recv, bool enquiryChk)
        {
            if (recv == null)                    //無応答
            {
                //エラー終了
                ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.TIMEOUT), System.Drawing.Color.Red);
                return true;    //エラー有
            }
            else
            {
                switch (recv[0])
                {
                    case (byte)CtrlChar.NAK:     //NAK
                        byte[] data = MakeSingleChar((byte)CtrlChar.EOT);
                        recv = Send(data, 1500); //送信
                                                 //エラー終了
                                                 //                        ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.DATAERR), System.Drawing.Color.Red);
                        ChangeInfo(0, 0, "NAKによる動作不可(RespCheck)", System.Drawing.Color.Red);
                        return true;    //エラー有

                    case (byte)CtrlChar.BEL:     //BEL
                        //動作中
                        ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.MOVE), System.Drawing.Color.Khaki);
                        return true;    //エラー有

                    case (byte)CtrlChar.SUB:     //SUB
                    case (byte)CtrlChar.SOH:     //SOH
                    case (byte)CtrlChar.EM:      //EM
                    case (byte)CtrlChar.DC1:     //DC1
                    case (byte)CtrlChar.DC2:     //DC2
                        //処理不可
                        ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.DISABLE), System.Drawing.Color.Khaki);
                        return true;    //エラー有

                    case (byte)CtrlChar.ACK:     //ACK
                        if (enquiryChk)                     //問い合わせチェックありなら実行
                        {
                            if (EnquiryCheck() == false)    //問い合わせチェック
                            {
                                return true;     //エラー有
                            }
                        }
                        return false;   //エラー無

                    case (byte)CtrlChar.RS:   //RS・ＲＡＳモード
                        ChangeInfo(0, 0, "RASモード中", System.Drawing.Color.Khaki);
                        return true;

                    default:                     //無効応答
                        data = MakeSingleChar((byte)CtrlChar.EOT);
                        recv = Send(data, 1500); //送信
                        //エラー終了
                        ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.DATAERR), System.Drawing.Color.Red);
                        return true;    //エラー有
                }
            }
        }

        //ENQ待ち処理
        public bool EnquiryCheck()
        {
            byte[] data = MakeSingleChar((byte)CtrlChar.ENQ);
            while (true)
            {
                SgNet.COM.Time_s.Sleep(500);      //0.5秒スリープ
                byte[] recv = Send(data, 1500);   //送信

                if (recv == null)                 //無応答
                {
                    //エラー終了
                    ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.TIMEOUT), System.Drawing.Color.Red);
                    return false;
                }
                else
                {
                    switch (recv[0])
                    {
                        case (byte)CtrlChar.CAN:  //CAN
                            //エラー終了
                            ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.ENQERR), System.Drawing.Color.Red);
                            return false;

                        case (byte)CtrlChar.SUB:  //SUB・動作中
                        case (byte)CtrlChar.DC2:  //DC2・抜き取り待ち
                            continue;

                        case (byte)CtrlChar.ACK:  //ACK・正常終了
                        case (byte)CtrlChar.ETB:  //ETB・ニアエンプティ
                        case (byte)CtrlChar.SYN:  //SYN・カセットＩＣ読み取り終了
                                                  //                        case (byte)CtrlChar.RS:   //RS・ＲＡＳモード
                        case (byte)CtrlChar.SOH:  //SOH・計数中
                        case (byte)CtrlChar.EM:   //EM・計数停止中
                        case (byte)CtrlChar.DC1:  //DC1・払い出し待ち
                        case (byte)CtrlChar.DC3:  //DC3・セット外れ
                            //正常終了
                            return true;

                        case (byte)CtrlChar.RS:   //RS・ＲＡＳモード
                            ChangeInfo(0, 0, "RASモード中", System.Drawing.Color.Khaki);
                            return true;

                        default:                  //無効応答
                            //エラー終了
                            ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.DATAERR), System.Drawing.Color.Red);
                            return false;
                    }
                }
            }
        }

        //レスポンスチェック（引数：受信データ）　戻り値：レスポンスのデータ部またはnull
        public byte[] RecvCheckAndGetData(byte[] recv)
        {
            if (recv == null)                     //無応答
            {
                //エラー終了
                ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.TIMEOUT), System.Drawing.Color.Red);
                return null;    //エラー有
            }
            else
            {
                byte[] ReceiveData = new byte[recv.Length];
                switch (recv[0])
                {
                    case (byte)CtrlChar.NAK:     //NAK
                        byte[] data = MakeSingleChar((byte)CtrlChar.EOT);
                        recv = Send(data, 1500); //送信
                                                 //エラー終了
                                                 //                        ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.DATAERR), System.Drawing.Color.Red);
                        ChangeInfo(0, 0, "NAKによる動作不可(RecvCheckAndGetData)", System.Drawing.Color.Red);
                        return null;    //エラー有

                    case (byte)CtrlChar.SUB:     //SUB
                        //処理不可
                        ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.DISABLE), System.Drawing.Color.Khaki);
                        return null;    //エラー有

                    case (byte)CtrlChar.DLE:     //DLE
                        //正常レスポンスデータ
                        for (int a = 0; a < (recv.Length - 6); a++)
                        {
                            ReceiveData[a] = (byte)(recv[4 + a] & 0x0F);   //データ部の下位４ビットを取り出し
                        }
                        return ReceiveData;

                    case (byte)CtrlChar.RS:   //RS・ＲＡＳモード
                        ChangeInfo(0, 0, "RASモード中", System.Drawing.Color.Khaki);
                        return null;

                    default:                     //無効応答
                        data = MakeSingleChar((byte)CtrlChar.EOT);
                        recv = Send(data, 1500); //送信
                        //エラー終了
                        ChangeInfo(0, 0, ErrorStrings((int)ErrorStringNo.DATAERR), System.Drawing.Color.Red);
                        return null;    //エラー有
                }
            }
        }

        private enum ErrorStringNo { TIMEOUT, DATAERR, MOVE, DISABLE, ENQERR }
        private string ErrorStrings(int strNo)
        {
            string[] strCN = {  "报错!   超时 , 通信异常",
                                "报错!   数据报错 , 指令报错",
                                "动作中 , 动作不可",
                                "动作不可",
                                "报错!   （询问处理中）" };
            string[] strJP = {  "エラー！　タイムアウト , 通信異常",
                                "エラー！　データエラー , コマンドエラー",
                                "動作中 , 動作不可",
                                "動作不可",
                                "エラー！　（問い合わせ処理中）" };
            switch (Lang)
            {
                case "CN":
                    return strCN[strNo];
                case "JP":
                    return strJP[strNo];
            }
            return "";
        }

        public void AmountErrorExec(bool modoshiflg, int pcs)
        {
            Cmd CmdAmtErr = new Cmd();
            CmdAmtErr.SequenceName = "";
            CmdAmtErr.Comment = "";
            CmdAmtErr.Maisu.Add("");
            CmdAmtErr.Maisu.Add("");
            CmdAmtErr.Maisu.Add("");
            CmdAmtErr.Maisu.Add("");
            CmdAmtErr.SequenceP.RunNo = 0;
            CmdAmtErr.SequenceP.Before1Hidouki = false;
            CmdAmtErr.SequenceP.Before2Hidouki = false;

            //ログリード
            CmdAmtErr.FileName = "Logread";
            CmdAmtErr.Parameter = "04,05,11,13,83,93,94";
            ChangeInfo(0, 2, "ログリード中　払い出し部から紙幣を取り出してください", System.Drawing.Color.Khaki);
            Logread cmdLogread = new Logread(CmdAmtErr, this, 2);//処理クラスのnew
            cmdLogread.MainFunc();

            //リセット
            CmdAmtErr.FileName = "Reset";
            CmdAmtErr.Parameter = "";
            ChangeInfo(0, 2, "リセット中", System.Drawing.Color.White);
            Reset cmdReset = new Reset(CmdAmtErr, this, 2);//処理クラスのnew
            cmdReset.MainFunc();

            //ＲＪロック解除
            CmdAmtErr.FileName = "RJLockRel";
            CmdAmtErr.Parameter = "";
            ChangeInfo(0, 2, "出金ＲＪロック解除中", System.Drawing.Color.White);
            RJLockRel cmdRJLockRel = new RJLockRel(CmdAmtErr, this, 2);//処理クラスのnew
            cmdRJLockRel.MainFunc();

            //リセット
            CmdAmtErr.FileName = "Reset";
            CmdAmtErr.Parameter = "";
            ChangeInfo(0, 2, "リセット中", System.Drawing.Color.White);
            cmdReset.MainFunc();

            CmdAmtErr.Parameter = "";
            CmdAmtErr.Maisu.RemoveAt(3);
            CmdAmtErr.Maisu.Add(pcs.ToString());
            ChangeInfo(0, 2, "払い出し部と出金ＲＪから取り出した紙幣を戻してください", System.Drawing.Color.Khaki);
            if (modoshiflg)
            {
                //現金戻し
                CmdAmtErr.FileName = "Modoshiire";
                Modoshiire cmdModoshiire = new Modoshiire(CmdAmtErr, this, 2);//処理クラスのnew
                cmdModoshiire.MainFunc();
            }
            else
            {
                //現金戻しができないモードでは入金で入れる
                CmdAmtErr.FileName = "Nyukin";
                Nyukin cmdNyukin = new Nyukin(CmdAmtErr, this, 2);//処理クラスのnew
                cmdNyukin.MainFunc();
            }

            ChangeInfo(0, 2, "", System.Drawing.Color.White);
        }

        public string GetErrCode = "";          //在高不一致判定用
        //状態リードコマンドからエラーコードを取得して表示
        public void GetErrorByConditionRead()
        {
            //状態リードコマンド
            string ercd = "";                   //エラーコード配列
            string name = "";                   //エラー名
            int len = 2;
            byte[] dt = new byte[len];          //データ部仮配列

            dt[0] = 0x38;                       //D0・リードデータ指定（８０固定）
            dt[1] = 0x30;                       //D1・リードデータ指定
            byte[] data = MakeSendData((byte)CmdCode.ConditionRead, len, dt);   //コマンド,データ長,データ部配列
            byte[] recv = Send(data, 1500);                                     //送信
            byte[] ReceiveData = RecvCheckAndGetData(recv);                     //recvからデータだけ取り出す
            if (ReceiveData == null)
            {
                GetErrCode = "";
                return;
            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    ercd += Convert.ToChar(ReceiveData[i] | 0x30);              //エラーコードを取り出す（D0～D3）
                }
                GetErrCode = ercd;              //在高不一致判定用にエラーコードをコピー
                if (ercd != "0000")
                {
                    name = GetErrorName(ercd);                                      //エラー名を取得
                    ChangeInfo(0, 1, ("E:" + ercd + "  " + name), System.Drawing.Color.Red);        //表示
                }
            }
        }

        //ＲＡＳセンスコマンドからエラーコードを取得して表示
        public void GetErrorByRASsense()
        {
            //ＲＡＳセンスコマンド
            string ercd = "";                   //エラーコード配列
            string name = "";                   //エラー名

            byte[] data = MakeSendData((byte)CmdCode.RASsense);                 //コマンド（データ長０のもの）
            byte[] recv = Send(data, 1500);                                     //送信
            byte[] ReceiveData = RecvCheckAndGetData(recv);                     //recvからデータだけ取り出す
            if (ReceiveData == null)
            {
                return;
            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    ercd += Convert.ToChar(ReceiveData[i + 6] | 0x30);          //エラーコードを取り出す（D6～D9）
                }
                if (ercd != "0000")
                {
                    name = GetErrorName(ercd);                                      //エラー名を取得
                    ChangeInfo(0, 1, ("E:" + ercd + "  " + name), System.Drawing.Color.Red);        //表示
                }
            }
        }

        List<string[]> ErrorData;
        //エラー名ファイルの読み込み
        private void SetErrorData()
        {
            string path = Application.StartupPath;
            switch (Lang)
            {
                case "CN":
                    path = path + "\\ErrStringC.ini";
                    break;
                case "JP":
                    path = path + "\\ErrStringJ.ini";
                    break;
            }
            //ErrString.iniが見つかったらファイル読み込み　ErrorData[][0]：エラーコード　ErrorData[][1]：エラー名
            if (SgNet.COM.File_s.Exists(path))
            {
                ErrorData = SgNet.COM.File_s.TSV_s.ReadFileString(path);
            }
        }
        //エラー名を取得
        private string GetErrorName(string ercd)
        {
            for (int er = 0; er < ErrorData.Count; er++)
            {
                if (ErrorData[er][0] == ercd)  //エラーコードが見つかったら対応するエラー名を返す
                {
                    return ErrorData[er][1];
                }
            }
            return "";                          //エラーコードが見つからない場合は空文字
        }

        //データ２バイトの下部４ビットずつをまとめて１バイトにする
        public byte CharMerge(byte a, byte b)
        {
            return (byte)(((a & 0x0F) << 4) + (b & 0x0F));
        }

        //各種データのファイル保存
        public bool Savevalue(string filename, List<string[]> data)
        {
            //フォルダの作成
            String path = Application.StartupPath + "\\Data";
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + Lot;
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + Unit;
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + SID;
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + filename;

            return SgNet.COM.File_s.TSV_s.WriteFile(path, data);
        }

        public bool SavevalueBin(string filename, byte[] data, bool AppendFlg)
        {
            //フォルダの作成
            String path = Application.StartupPath + "\\Data";
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + Lot;
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + Unit;
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + SID;
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + filename;

            System.IO.FileStream fs = SgNet.COM.File_s.Bin_s.OpenWriteFile(path, AppendFlg);
            bool result = SgNet.COM.File_s.Bin_s.WriteFile(data, fs);
            SgNet.COM.File_s.Bin_s.CloseFile(fs);

            return result;
        }

        //**********************************************************


        //実際の送信部
        public byte[] Send(byte[] data, int timeout)
        {
            //受信バッファのクリア
            RecvData.Clear();
            RecvInfo.Clear();

            //受信サイズを0にする
            RecvDataSize = 0;

            //ログに追加
            AddList(data, true);
            System.IO.StreamWriter sw = SgNet.COM.File_s.Text_s.OpenWriteFile(Application.StartupPath + "\\CommLog.txt", true);
            String buf = "";
            this.Invoke((MethodInvoker)delegate
            {
                buf = listBox1.Items[listBox1.Items.Count - 1].ToString();
            });
            SgNet.COM.File_s.Text_s.WriteFileRow(buf, sw);
            sw.Close();

            //タイムアウト用タイマーをスタートする
            TimeOutTime = timeout;
            TimeOutTimer.Change(TimeOutTime, -1);//起動

            //データ送信
            EndFlg = false;
            SioP.Send(data);

            //データの受信待ち
            while (RecvInfo.Count == 0)
            {
                System.Threading.Thread.Sleep(1);
                if (EndFlg == true) return null;
                if (ForceStopFlg == true) return null;
            }

            //念のためにスリープ
            SgNet.COM.Time_s.Sleep(5);

            //受信データを受け取ってバッファをクリア
            int syori = RecvInfo[0];  //1=正常ﾚｽﾎﾟﾝｽ 0=相手からの勝手なﾚｽﾎﾟﾝｽ -1=ﾀｲﾑｱｳﾄ
            RecvInfo.Clear();

            byte[] recvData = RecvData[0];
            RecvData.Clear();

            //ログに追加
            if (recvData != null)
            {
                //AddList(recvData, false);

                //sw = SgNet.COM.File_s.Text_s.OpenWriteFile(Application.StartupPath + "\\CommLog.txt", true);
                //buf = "";
                //this.Invoke((MethodInvoker)delegate
                //{
                //    buf = listBox1.Items[listBox1.Items.Count - 1].ToString();
                //});
                //SgNet.COM.File_s.Text_s.WriteFileRow(buf, sw);
                //sw.Close();
            }

            //機種毎に変更必要   ****************************************
            //受信データの解析等
            if (syori == 1)
            {
                //正常レスポンス
                return recvData;
            }
            else if (syori == 0)
            {
                //ゴミレスポンス
                AddList("Gomi");
                sw = SgNet.COM.File_s.Text_s.OpenWriteFile(Application.StartupPath + "\\CommLog.txt", true);
                buf = "";
                this.Invoke((MethodInvoker)delegate
                {
                    buf = listBox1.Items[listBox1.Items.Count - 1].ToString();
                });
                SgNet.COM.File_s.Text_s.WriteFileRow(buf, sw);
                sw.Close();

            }
            else
            {
                //タイムアウトまたは通信不良
                if (recvData != null)
                {
                    AddList("Timeout");
                    sw = SgNet.COM.File_s.Text_s.OpenWriteFile(Application.StartupPath + "\\CommLog.txt", true);
                    buf = "";
                    this.Invoke((MethodInvoker)delegate
                    {
                        buf = listBox1.Items[listBox1.Items.Count - 1].ToString();
                    });
                    SgNet.COM.File_s.Text_s.WriteFileRow(buf, sw);
                    sw.Close();

                }
            }
            return null;
            //**********************************************************
        }

        //受信イベント ※ここでデータの長さの正しさなどを精査してRecvCmdを読み出す
        private void RecvEvent(byte[] recvData)
        {
            if (recvData == null) return;       //ないと思うけど
            if (recvData.Length == 0) return;   //ないと思うけど

            //ログに追加
            AddList(recvData, false);
            System.IO.StreamWriter sw = SgNet.COM.File_s.Text_s.OpenWriteFile(Application.StartupPath + "\\CommLog.txt", true);
            String buf = "";
            this.Invoke((MethodInvoker)delegate
            {
                buf = listBox1.Items[listBox1.Items.Count - 1].ToString();
            });
            SgNet.COM.File_s.Text_s.WriteFileRow(buf, sw);
            sw.Close();

            int len = recvData.Length;
            //データをバッファにコピー
            Array.Copy(recvData, 0, RecvDataBuf, (RecvDataSize == -1 ? 0 : RecvDataSize), len);

            //ﾀｲﾑｱｳﾄ後のﾚｽﾎﾟﾝｽだったり 相手からの勝手なﾚｽﾎﾟﾝｽの場合
            if (RecvDataSize == -1)
            {
                byte[] d = null;
                if (len != 0)
                {
                    d = new byte[len];
                    Array.Copy(RecvDataBuf, d, len);
                }
                RecvCmd(0, d);
                return;
            }
            RecvDataSize += len;

            //受信データの分解
            while (true)
            {
                //タイムアウトを一旦停止する
                TimeOutTimer.Change(-1, -1);          //停止

                //機種毎に変更必要   ***************************************
                //データの長さ確認を行う　　　　
                int okLen;
                if (RecvDataBuf[0] == (byte)CtrlChar.DLE)
                {
                    if (RecvDataSize >= 6)
                    {   //レングス情報をもとに計算
                        okLen = 6 + (RecvDataBuf[2] & 0x0F) * 16 + (RecvDataBuf[3] & 0x0F);
                    }
                    else
                    {   //レングス情報受信までは暫定でデータ部以外のサイズ６を入れておく
                        okLen = 6;
                    }
                }
                else
                {   //DLEでない場合は１キャラクタレスポンスとみなす
                    okLen = 1;
                }
                //**********************************************************

                //読み取り終了の条件式
                if (okLen <= RecvDataSize)
                {
                    //データがそろった時
                    //イベントで上位に通知する
                    byte[] d = null;
                    if (okLen != 0)
                    {
                        d = new byte[okLen];
                        Array.Copy(RecvDataBuf, d, okLen);
                    }
                    RecvDataSize -= okLen;
                    //正常受信送信
                    //RecvCmd(1, d);
                    if (RecvDataSize == 0)
                    {
                        RecvDataSize = -1;
                        //break;
                    }
                    else
                    {
                        //データを前に詰める
                        for (int a = 0; a < RecvDataSize; a++)
                        {
                            RecvDataBuf[a] = RecvDataBuf[okLen + a];
                        }
                    }
                    RecvCmd(1, d);
                    if (RecvDataSize == -1) break;
                }
                else
                {
                    //データがそろっていない時
                    //タイムアウトタイマーを起動する
                    TimeOutTimer.Change(TimeOutTime, -1);//起動
                    break;
                }
            }
        }

        //受信データチェック
        private void RecvCmd(int recvFlg/*1=正常ﾚｽﾎﾟﾝｽ 0=相手からの勝手なﾚｽﾎﾟﾝｽ -1=ﾀｲﾑｱｳﾄ*/, byte[] data)
        {
            RecvData.Add(data);
            RecvInfo.Add(recvFlg);
        }

        //タイムアウト用イベント
        private void TimeOutClock(object o)
        {
            //タイムアウト用タイマーをストップ
            TimeOutTimer.Change(-1, -1);

            //イベントで上位に上げる
            byte[] d = null;
            if (RecvDataSize > 0)
            {
                d = new byte[RecvDataSize];
                Array.Copy(RecvDataBuf, d, RecvDataSize);
                RecvDataSize = -1;
            }
            RecvCmd(-1, d);
        }

        #endregion 通信処理
        //***********************************************************************************************
    }
}
