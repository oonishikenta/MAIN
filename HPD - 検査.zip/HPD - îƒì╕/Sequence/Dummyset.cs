﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Dummyset
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Dummyset(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                int len = 6;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・設定機種
                dt[1] = 0x31;                   //D1・設定機種（１：紙幣部固定）
                dt[2] = 0x32;                   //D2・ＳＷNo.（16^1）
                dt[3] = 0x3A;                   //D3・ＳＷNo.（16^0）（４２(0x2A)：計数モード設定）
                dt[4] = 0x30;                   //D4・設定データ（16^1）
                dt[5] = 0x31;                   //D5・設定データ（16^0）（１：ダミーモード）

                //ＳＳＷ設定コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWWrite, len, dt);    //コマンド,データ長,データ部配列
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
