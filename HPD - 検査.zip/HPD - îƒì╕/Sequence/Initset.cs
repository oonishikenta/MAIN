﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Initset
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Initset(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        static int swnum_block = 100;
        static int swnum = 200;

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                string param = CmdP.Parameter;                  //パラメータの欄から文字列を取得する

                string[] swval_para = param.Split(',');         //（チェックデータ）カンマ区切りで分割して配列に格納する
                if (swval_para.Length != swnum)
                {
                    err = true;
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            OwnerP.ChangeInfo(0, 0, "参数异常", System.Drawing.Color.Red);
                            break;
                        case "JP":
                            OwnerP.ChangeInfo(0, 0, "パラメータ異常", System.Drawing.Color.Red);
                            break;
                    }
                    break;
                }

                byte[] swval_resp = new byte[swnum];

                int len = 6;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・設定機種
                dt[1] = 0x31;                   //D1・設定機種（１：紙幣部固定）
                dt[2] = 0x30;                   //D2・ＳＷNo.（16^1）
                dt[3] = 0x30;                   //D3・ＳＷNo.（16^0）（０：全ＳＷデフォルト設定）
                dt[4] = 0x30;                   //D4・設定データ（16^1）
                dt[5] = 0x30;                   //D5・設定データ（16^0）（ＳＷNo.が０のとき０固定）

                //ＳＳＷ設定コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWWrite, len, dt);    //コマンド,データ長,データ部配列
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                if (err == false)
                {
                    SgNet.COM.Time_s.Sleep(500);                //0.5秒スリープ

                    len = 4;
                    dt[0] = 0x30;               //D0・リード方法（０：一括）
                    dt[1] = 0x31;               //D1・機種（１：紙幣部固定）
                    dt[2] = 0x30;               //D2・ＳＷNo.
                    dt[3] = 0x30;               //D3・ＳＷNo.（０：１～１００）

                    //ＳＳＷリードコマンド（１～１００）
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWRead, len, dt);        //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 1500);                             //送信
                    byte[] ReceiveData = OwnerP.RecvCheckAndGetData(recv);      //recvからデータだけ取り出す

                    if (ReceiveData != null)
                    {
                        //設定値を取得
                        //CharMerge(a,b)：データ２バイトの下部４ビットずつをまとめて１バイトにする
                        for (int i = 0; i < swnum_block; i++)
                        {
                            swval_resp[i] = OwnerP.CharMerge(ReceiveData[2 * i + 4], ReceiveData[2 * i + 5]);
                        }
                    } else {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;
                    }

                    dt[3] = 0x31;               //D3・ＳＷNo.（１：１０１～２００）
                    //ＳＳＷリードコマンド（１０１～２００）
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.SetSWRead, len, dt);        //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 1500);                             //送信
                    ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す

                    if (ReceiveData != null)
                    {
                        for (int i = swnum_block; i < swnum; i++)
                        {
                            swval_resp[i] = OwnerP.CharMerge(ReceiveData[2 * i + 4 - (swnum_block * 2)], 
                                                             ReceiveData[2 * i + 5 - (swnum_block * 2)]);
                        }
                    }
                    else {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;
                    }

                    //設定値をファイル保存
                    List<string[]> Data = new List<string[]>();
                    string[] DataValue = new string[swnum];
                    string DispData = "";
                    for (int i = 0; i < swnum; i++)
                    {
                        DataValue[i] = swval_resp[i].ToString();
                        DispData += DataValue[i] + "\t";
                        if (i % 5 == 4) {DispData += "\r\n";}
                    }
                    Data.Add(DataValue);
                    OwnerP.ChangeInfo(2, 0, DispData, System.Drawing.Color.White);
                    OwnerP.Savevalue("Initset.csv", Data);

                    //データ比較
                    for (int n = 0; n < swnum; n++)
                    {
                        if (swval_para[n] != swval_resp[n].ToString("X2"))
                        {
                            err = true;
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 0, "数据不一样 : No." + (n + 1), System.Drawing.Color.Red);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 0, "データ不一致 : No." + (n + 1), System.Drawing.Color.Red);
                                    break;
                            }
                            break;
                        }
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
