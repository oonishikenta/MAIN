﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

//「機種毎に変更必要」と書かれている部分を修正のこと
namespace Simulator
{
    public partial class AgingSelect : Form
    {
        //フォームステータス
        private FormStatus NowStatus = FormStatus.Wait;

        //コマンドフォーム
        SQMain SQFrm = null;

        //アドレス
        String Address = "";

        //接続数
        int ConnectionCount = 1;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public AgingSelect()
        {
            InitializeComponent();
        }

        //All Close
        private void button3_Click(object sender, EventArgs e)
        {
            SgNet.COM.File_s.IniFile_s iniP = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\AgingSelect.ini");
            iniP.WriteInt("Settings", "EndFlg", 1);
            iniP.Save();

            if (SQFrm != null)
            {
                SQFrm.ForceStop();
                SQFrm.FormDispose();

                //500ms切断待機
                int start = System.Environment.TickCount;          // ミリ秒単位で経過時間を取得
                while ((System.Environment.TickCount - start) < 500)
                {
                    System.Windows.Forms.Application.DoEvents();
                    System.Threading.Thread.Sleep(1);
                }
                SQFrm = null;
            }
        }

        //Stanby
        private void button2_Click(object sender, EventArgs e)
        {
            SgNet.COM.File_s.IniFile_s iniP = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\AgingSelect.ini");
            iniP.WriteInt("Settings", "EndFlg", 0);
            iniP.Save();

            for (int i = (panel1.Visible ? 1 : 0); i < ConnectionCount; i++)
            {
                SgNet.COM.Process_s.ApplicationStart(Application.StartupPath + "\\AgingMain.exe", new String[]{i.ToString()}, false);
            }
        }

        //アドレス変更
        private void button4_Click(object sender, EventArgs e)
        {
            int sel = comboBox1.SelectedIndex;
            if (sel == -1) return;
            FormStatusChange(FormStatus.Move);
            Cmd cmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\ChangeAddress.xml");
            cmd.Parameter = sel.ToString();
            bool ret = StartCmd(cmd, null, -1, -1);
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + "\\MsgString.ini", "Msg", "3", "There are some errors!");
            }
        }

        //設定
        private void button1_Click(object sender, EventArgs e)
        {
            AgingSettings dlgP = new AgingSettings();
            dlgP.ShowDialog();
            this.Close();
        }

        //SQFormのShow
        private void button5_Click(object sender, EventArgs e)
        {
            SQFormShow();
        }

        private string FileNameOfMsgString()
        {
            return "\\MsgStringJ.ini";
        }
        private string FileNameOfFormString()
        {
            return "\\FormStringJ.ini";
        }

        private void AgingSelect_Load(object sender, EventArgs e)
        {
            this.Text += " Version=" + SgNet.COM.Application_s.Version(System.Reflection.Assembly.GetExecutingAssembly());
            
            //debug******初期のファイルを作成するとき*************
            //SgNet.COM.Form_s.SaveString(Application.StartupPath + "\\FormString.ini", this);
            //****************************************************

            //画面のフォント・文字変更
            SgNet.COM.Form_s.LoadString(Application.StartupPath + FileNameOfFormString(), this);
            
            SgNet.COM.File_s.IniFile_s iniP = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\Settings.ini");

            ConnectionCount = iniP.ReadInt("Aging", "ConnectionCount", 1);
            panel1.Visible = (iniP.ReadInt("Aging", "AddressChange", 0) == 0? false : true);

            FormStatusChange(FormStatus.Wait);

            if (panel1.Visible == true)
            {
                Address = iniP.ReadString("Aging", "Address0", "0");

                //CmdFormの通知イベント設定
                SQFrm = new SQMain(this, Address, iniP, "", "", "", "");
                SQFrm.ChangeInfoEvent += new SQMain.DelegateChangeInfo(ChangeInfo);
                SQFrm.ChangeFormColorEvent += new SQMain.DelegateChangeFormColor(ChangeFormColor);
                SQFrm.ChangeMaisuEvent += new SQMain.DelegateChangeMaisu(ChangeMaisu);
                SQFrm.NotifyCompleteEvent += new SQMain.DelegateNotifyComplete(NotifyComplete);
                SQFrm.NotifyCompleteMultiLineEvent += new SQMain.DelegateNotifyCompleteMultiLine(NotifyCompleteMultiLine);
                SQFrm.ChangeProgressBarEvent += new SQMain.DelegateChangeProgressBar(ChangeProgressBar);
                SgNet.COM.Form_s.HideShow(SQFrm);
            }

            for(int i=1; i<ConnectionCount; i++)
            {
                comboBox1.Items.Add(iniP.ReadString("Aging", "Address" + i.ToString(), i.ToString()));
            }
            if (comboBox1.Items.Count > 0) comboBox1.SelectedIndex = 0;

            //最前面に表示
            SgNet.COM.Form_s.ShowTopMost(this);

            //起動
            button2_Click(null, null);
        }

        private void AgingSelect_FormClosing(object sender, FormClosingEventArgs e)
        {
            button3_Click(null, null);
        }

        //GUIから下位への命令****************************
        //フォームの表示
        void SQFormShow()
        {
            SQFrm.FormShow();
        }
        //Dispose
        void SQFormDispose()
        {
            SQFrm.FormDispose();
        }
        //コマンドの開始
        bool StartCmd(Cmd cmd, List<PatternRow> list, int nowRow, int nowCol)
        {
            if (cmd == null)
            {
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "4", "There's not the command.");
                return false;
            }
            return SQFrm.StartCmd(cmd, list, nowRow, nowCol);
        }
        //強制停止
        bool ForceStop()
        {
            return SQFrm.ForceStop();
        }

        //下位からGUIへの通知****************************
        //GUIの各種情報変更通知
        void ChangeInfo(int unitNo, int idNo, String infoString, Color labelColor)
        {
        }

        //GUIのフォームの色を変える
        void ChangeFormColor(Color formColor)
        {
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                this.BackColor = formColor;
            });
        }

        //GUIへの枚数変更通知
        void ChangeMaisu(List<int> maisu, int rowNo)
        {
        }

        //GUIへの完了通知
        void NotifyComplete(bool errorFlg, String value)
        {
            if (errorFlg)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
            else
            {
                FormStatusChange(FormStatus.Wait);
                SgNet.COM.MessageBox_s.ShowInfomation(Application.StartupPath + FileNameOfMsgString(), "Msg", "9", "Address change complete.");
            }
        }

        //品証ツールなどの複数行まとめて実行時の処理
        void NotifyCompleteMultiLine(List<PatternRow> list)
        {
        }

        /// <summary>
        /// GUIへのプログレスバー変更通知
        /// </summary>
        /// <param name="max">最大値</param>
        /// <param name="val">現在値　※0の時プログレスバーが非表示になる</param>
        void ChangeProgressBar(uint max, uint val)
        {
        }

        /// <summary>
        /// フォームステータス
        /// </summary>
        private enum FormStatus
        {
            Wait,
            Move,
            Error,
            Comp
        }
        /// <summary>
        /// フォームのステータス変更
        /// </summary>
        /// <param name="status"></param>
        private void FormStatusChange(FormStatus status)
        {
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                NowStatus = status;

                switch (status)
                {
                    case FormStatus.Wait:
                        button4.Visible = true;
                        this.BackColor = Color.LightYellow;
                        break;

                    case FormStatus.Move:
                        button4.Visible = false;
                        this.BackColor = Color.DeepSkyBlue;
                        break;

                    case FormStatus.Error:
                        button4.Visible = true;
                        this.BackColor = Color.Pink;
                        break;

                    case FormStatus.Comp:
                        button4.Visible = true;
                        this.BackColor = Color.Green;
                        break;
                }
            });
        }
    }
}
