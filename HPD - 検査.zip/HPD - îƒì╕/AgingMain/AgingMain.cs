﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

//「機種毎に変更必要」と書かれている部分を修正のこと
namespace Simulator
{
    public partial class AgingMain : Form
    {
        //Start・Stop・Reset・Endボタンの表示ポジション
        private Point ButtonLocation = new Point(3, 3);

        //フォームステータス
        private FormStatus NowStatus = FormStatus.Wait;

        //アドレス
        private String Address = "";
        private int AddressVal = 0;

        //エージングカウント
        int AgingEndCount = 0;
        int AgingCount = 0;

        //エージング２カウント
        int Aging2EndCount = 0;
        int Aging2Count = 0;
        int Aging2Interval = 0;
        private bool Aging2Flg = false;

        //停止フラグ
        private bool StopFlg = false;

        //シングルコマンド時
        private bool SingleFlg = false;

        //アドレスチェンジを使うかどうか
        bool AddressChangeFlg = false;

        //エージング一番最初のReset用フラグ
        private bool FirstFlg = true;

        Cmd ResetCmd = null;//CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\Reset.xml");
        Cmd AgingCmd = null;//CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\Aging.xml");
        Cmd Aging2Cmd = null;//CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\Aging2.xml");
        Cmd RasstopCmd = null;//CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\Rasstop.xml");
        Cmd DateTimeSetCmd = null;//CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\DateTimeSet.xml");
        Cmd ChangeAddress = null;//CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\ChangeAddress.xml");

        //Setting.ini
        private SgNet.COM.File_s.IniFile_s SettingIni = new SgNet.COM.File_s.IniFile_s(Application.StartupPath + "\\Settings.ini");
        
        //インフォーメーションの表示状況
        private bool Infomation_BigPanel = false;
        private bool Infomation_LittlePanel = false;
        private bool Infomation_MaisuPanel = false;

        //インフォーメーションのラベル
        Label[] UnitInfo1 = null;
        Label[] UnitInfo2 = null;

        //コマンドフォームの作成　とりあえずアドレス0で起動している
        SQMain SQFrm = null;

        //splitContainer2.Panel1の最初のサイズ
        Size P1Size = new Size(1, 1);

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public AgingMain()
        {
            InitializeComponent();
            try
            {
                if(SgNet.COM.File_s.Exists(Application.StartupPath + "\\Command\\Reset.xml"))
                    ResetCmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\Reset.xml");
            }
            catch { }
            try
            {
                if (SgNet.COM.File_s.Exists(Application.StartupPath + "\\Command\\Aging.xml"))
                    AgingCmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\Aging.xml");
            }
            catch { }
            try
            {
                if (SgNet.COM.File_s.Exists(Application.StartupPath + "\\Command\\Aging2.xml"))
                    Aging2Cmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\Aging2.xml");
            }
            catch { }
            try
            {
                if (SgNet.COM.File_s.Exists(Application.StartupPath + "\\Command\\Rasstop.xml"))
                    RasstopCmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\Rasstop.xml");
            }
            catch { }
            try
            {
                if (SgNet.COM.File_s.Exists(Application.StartupPath + "\\Command\\DateTimeSet.xml"))
                    DateTimeSetCmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\DateTimeSet.xml");
            }
            catch { }
            try
            {
                if (SgNet.COM.File_s.Exists(Application.StartupPath + "\\Command\\ChangeAddress.xml"))
                    ChangeAddress = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\ChangeAddress.xml");
            }
            catch { }
        }

        /// <summary>
        /// フォームステータス
        /// </summary>
        private enum FormStatus
        {
            Wait,
            Move,
            Error,
            Comp
        }

        /// <summary>
        /// 判定ステータス
        /// </summary>
        private enum ResultStatus
        {
            OK,
            NG,
            None
        }

        /// <summary>
        /// フォームのステータス変更
        /// </summary>
        /// <param name="status"></param>
        private void FormStatusChange(FormStatus status)
        {
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                NowStatus = status;

                switch (status)
                {
                    case FormStatus.Wait:
                        StartBtn.Visible = true;
                        StopBtn.Visible = false;
                        ResetBtn.Visible = false;
                        button1.Enabled = true;
                        this.BackColor = Color.LightYellow;
                        break;

                    case FormStatus.Move:
                        StartBtn.Visible = false;
                        StopBtn.Visible = true;
                        StopBtn.Focus();
                        ResetBtn.Visible = false;
                        button1.Enabled = false;
                        this.BackColor = Color.DeepSkyBlue;
                        break;

                    case FormStatus.Error:
                        StartBtn.Visible = false;
                        StopBtn.Visible = false;
                        ResetBtn.Visible = true;
                        ResetBtn.Focus();
                        button1.Enabled = true;
                        this.BackColor = Color.Pink;
                        break;

                    case FormStatus.Comp:
                        StartBtn.Visible = true;
                        StopBtn.Visible = false;
                        ResetBtn.Visible = false;
                        button1.Enabled = true;
                        this.BackColor = Color.Green;
                        break;
                }
            });
        }

        /// <summary>
        /// キーダウンイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F1:
                    if (NowStatus == FormStatus.Wait)
                    {
                        StartBtn_Click(null, null);
                    }
                    break;

                case Keys.F2:
                    if (NowStatus == FormStatus.Move)
                    {
                        StopBtn_Click(null, null);
                    }
                    break;

                case Keys.F3:
                    if (NowStatus == FormStatus.Error)
                    {
                        ResetBtn_Click(null, null);
                    }
                    break;
            }
        }

        /// <summary>
        /// フォームクロージングイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopBtn_Click(null, null);
            if (SQFrm != null) SQFrm.FormDispose();
            SgNet.COM.Time_s.Sleep(100);
        }

        /// <summary>
        /// デバッグ画面表示のチェック変更
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DebugCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (DebugCheckBox.Checked == true)
            {
                this.ClientSize = new Size(splitContainer2.Size.Width, splitContainer2.Size.Height);
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    //SplitContainerのpanel2の表示
                    splitContainer2.Panel2Collapsed = false;
                    splitContainer2.BorderStyle = BorderStyle.FixedSingle;
                });
            }
            else
            {
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    this.ClientSize = P1Size;
                    //SplitContainerのpanel2の非表示
                    splitContainer2.Panel2Collapsed = true;
                    splitContainer2.BorderStyle = BorderStyle.None;
                });
            }
        }

        private string FileNameOfMsgString()
        {
            return "\\MsgStringJ.ini";
        }
        private string FileNameOfFormString()
        {
            return "\\FormStringJ.ini";
        }

        /// <summary>
        /// フォームロード
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_Load(object sender, EventArgs e)
        {
            //debug******初期のファイルを作成するとき*************
            //SgNet.COM.Form_s.SaveString(Application.StartupPath + "\\FormString.ini", this);
            //****************************************************
            String path1 = Application.StartupPath + "\\CommLog.txt";
            String path2 = Application.StartupPath + "\\CommLog1.txt";
            String path3 = Application.StartupPath + "\\CommLog2.txt";
            String path4 = Application.StartupPath + "\\CommLog3.txt";
            if (SgNet.COM.File_s.Exists(path4)) SgNet.COM.File_s.Delete(path4);
            if (SgNet.COM.File_s.Exists(path3)) SgNet.COM.File_s.Move(path3, path4);
            if (SgNet.COM.File_s.Exists(path2)) SgNet.COM.File_s.Move(path2, path3);
            if (SgNet.COM.File_s.Exists(path1)) SgNet.COM.File_s.Move(path1, path2);

            //画面のフォント・文字変更
            SgNet.COM.Form_s.LoadString(Application.StartupPath + FileNameOfFormString(), this);

            //Start/Stop/Reset/Endボタンの位置変更
            StartBtn.Location = ButtonLocation;
            StopBtn.Location = ButtonLocation;
            ResetBtn.Location = ButtonLocation;

            //引数からアドレスの取得
            String[] str = SgNet.COM.Application_s.CmdLine();
            if (str.Length <= 1) SgNet.COM.Application_s.Exit();
            int.TryParse(str[1], out AddressVal);
            Address = SettingIni.ReadString("Aging", "Address" + str[1], str[1]);
            label2.Text = "Address=" + Address;

            //エージング数の設定
            AgingEndCount = SettingIni.ReadInt("Aging", "Count", 0);
            label1.Text = AgingCount.ToString() + " / " + AgingEndCount.ToString();

            //エージング２の設定
            Aging2EndCount = SettingIni.ReadInt("Aging", "Aging2Count", 500);
            label4.Text = Aging2Count.ToString() + " / " + Aging2EndCount.ToString();
            Aging2Interval = SettingIni.ReadInt("Aging", "Aging2Interval", 1);
            Aging2Cmd.Parameter = Aging2EndCount.ToString() + "," + Aging2Interval.ToString();

            //アドレスチェンジを使うか？
            AddressChangeFlg = (SettingIni.ReadInt("Aging", "AddressChange", 0) == 0 ? false : true);
            if (AddressChangeFlg == false) button1.Visible = false;

            //Infomationの設定
            Infomation_BigPanel = (SettingIni.ReadInt("Settings", "Infomation_BigPanel", 0) == 0 ? false : true);
            Infomation_LittlePanel = (SettingIni.ReadInt("Settings", "Infomation_LittlePanel", 0) == 0 ? false : true);
            Infomation_MaisuPanel = (SettingIni.ReadInt("Settings", "Infomation_MaisuPanel", 0) == 0 ? false : true);

            P1Size = new Size(splitContainer2.Panel1.Width, splitContainer2.SplitterDistance);
            
            //自分の表示位置へ移動する
            int row = AddressVal / 2;
            int col = AddressVal % 2;
            this.Location = new Point((P1Size.Width + 15) * col, 75 + (P1Size.Height + 40) * row);

            int top = panel1.Location.Y;
            int delsize = 0;
            Size p3Size = new Size(panel3.Size.Width, panel3.Size.Height);
            if (!Infomation_BigPanel)
            {
                panel1.Visible = false;
                delsize += panel1.Height;
            }
            if (!Infomation_LittlePanel)
            {
                panel2.Visible = false;
                delsize += panel2.Height;
            }
            if (!Infomation_MaisuPanel)
            {
                panel3.Visible = false;
                delsize += panel3.Height;
            }

            int height = splitContainer2.SplitterDistance;
            splitContainer2.Size = new Size(splitContainer2.Width, splitContainer2.Height - delsize);
            splitContainer2.SplitterDistance = height;

            if (Infomation_BigPanel)
            {
                panel1.Visible = true;
                panel1.Location = new Point(24, top);
                top += panel1.Height;
            }
            if (Infomation_LittlePanel)
            {
                panel2.Visible = true;
                panel2.Location = new Point(24, top);
                top += panel2.Height;
            }
            if (Infomation_MaisuPanel)
            {
                panel3.Visible = true;
                panel3.Location = new Point(24, top);
                panel3.Size = p3Size;
                top += panel3.Height;

                KinsyuInfoGrid.Visible = false;
                InfomationTextBox.Location = new Point(KinsyuInfoGrid.Location.X, KinsyuInfoGrid.Location.X);
                InfomationTextBox.Size = new Size(KinsyuInfoGrid.Size.Width + InfomationTextBox.Size.Width, InfomationTextBox.Size.Height);
            }

            //インフォーメーションのラベル設定
            UnitInfo1 = new Label[]
            {
                Info1_1,
                Info1_2,
                Info1_3
            };
            UnitInfo2 = new Label[]
            {
                Info2_1_1,
                Info2_1_2,
                Info2_1_3,
                Info2_1_4,
                Info2_1_5,
                Info2_1_6,
                Info2_1_7,
                Info2_1_8,
                Info2_2_1,
                Info2_2_2,
                Info2_2_3,
                Info2_2_4,
                Info2_2_5,
                Info2_2_6,
                Info2_2_7,
                Info2_2_8,
                Info2_3_1,
                Info2_3_2,
                Info2_3_3,
                Info2_3_4,
                Info2_3_5,
                Info2_3_6,
                Info2_3_7,
                Info2_3_8,
            };

            FormStatusChange(FormStatus.Wait);

            //CmdFormの通知イベント設定
            SQFrm = new SQMain(this, Address, SettingIni, "", "", "", "JP");
            SQFrm.ChangeInfoEvent += new SQMain.DelegateChangeInfo(ChangeInfo);
            SQFrm.ChangeFormColorEvent += new SQMain.DelegateChangeFormColor(ChangeFormColor);
            SQFrm.ChangeMaisuEvent += new SQMain.DelegateChangeMaisu(ChangeMaisu);
            SQFrm.NotifyCompleteEvent += new SQMain.DelegateNotifyComplete(NotifyComplete);
            SQFrm.NotifyCompleteMultiLineEvent += new SQMain.DelegateNotifyCompleteMultiLine(NotifyCompleteMultiLine);
            SQFrm.ChangeProgressBarEvent += new SQMain.DelegateChangeProgressBar(ChangeProgressBar);
            SgNet.COM.Form_s.HideShow(SQFrm);

            //デバッグ情報を消す
            DebugCheckBox_CheckedChanged(null, null);


            //最前面に表示
            SgNet.COM.Form_s.ShowTopMost(this);
        }

        /// <summary>
        /// スタートボタン押下
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartBtn_Click(object sender, EventArgs e)
        {
            SingleFlg = false;
            FirstFlg = true;
            //書かれている終了回数を消す
            AgingCount = 0;
            Aging2Count = 0;
            label1.Text = AgingCount.ToString() + " / " + AgingEndCount.ToString();
            label4.Text = Aging2Count.ToString() + " / " + Aging2EndCount.ToString();

            StopFlg = false;

            FormStatusChange(FormStatus.Move);

            //日時設定
            bool ret = StartCmd(DateTimeSetCmd, null, -1, -1);//文字列はファイル名の拡張子を除いたもの
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
            else
            {
                while (SQFrm.MainThread1 != null)
                {
                    System.Windows.Forms.Application.DoEvents();
                    System.Threading.Thread.Sleep(1);
                }
                //実行
                ret = StartCmd(ResetCmd, null, -1, -1);//最初のリセット送信・文字列はファイル名の拡張子を除いたもの
                if (ret == false)
                {
                    FormStatusChange(FormStatus.Error);
                    SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
                }
            }
        }

        /// <summary>
        /// ストップボタン押下
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StopBtn_Click(object sender, EventArgs e)
        {
            StopFlg = true;
            if (Aging2Flg == true)
            {
                //エージング２中ならスレッドを強制停止、ＲＡＳ継続動作終了コマンドを送る
                SQFrm.ForceStop();
                //必要に応じてスリープ
                SgNet.COM.Time_s.Sleep(200);
                bool ret = StartCmd(RasstopCmd, null, -1, -1);//文字列はファイル名の拡張子を除いたもの
                if (ret == false)
                {
                    FormStatusChange(FormStatus.Error);
                    SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
                }
            }
            SgNet.COM.Time_s.SleepBreak();
        }

        /// <summary>
        /// リセットボタン押下
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetBtn_Click(object sender, EventArgs e)
        {
            StopFlg = true;
            SingleFlg = true;
            FirstFlg = false;

            FormStatusChange(FormStatus.Move);

            bool ret = StartCmd(ResetCmd, null, -1, -1);//単発リセット送信・文字列はファイル名の拡張子を除いたもの
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
        }

        //GUIから下位への命令****************************
        //フォームの表示
        void SQFormShow()
        {
            SQFrm.FormShow();
        }
        //Dispose
        void SQFormDispose()
        {
            SQFrm.FormDispose();
        }
        //コマンドの開始
        bool StartCmd(Cmd cmd, List<PatternRow> list, int nowRow, int nowCol)
        {
            if (cmd == null)
            {
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "4", "There's not the command.");
                return false;
            }
            return SQFrm.StartCmd(cmd, list, nowRow, nowCol);
        }
        //強制停止
        bool ForceStop()
        {
            return SQFrm.ForceStop();
        }

        //下位からGUIへの通知****************************
        //GUIの各種情報変更通知
        void ChangeInfo(int unitNo, int idNo, String infoString, Color labelColor)
        {
            if (idNo == -1) return;
            Label l = null;
            TextBox t = null;
            try
            {
                switch (unitNo)
                {
                    case 0: l = UnitInfo1[idNo]; break;
                    case 1: l = UnitInfo2[idNo]; break;
                    case 2: t = InfomationTextBox; break;
                }
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    if (l != null)
                    {
                        l.Text = infoString;
                        if (labelColor != null)
                        {
                            l.BackColor = labelColor;
                            l.ForeColor = SgNet.COM.Form_s.Color(255 - labelColor.R, 255 - labelColor.G, 255 - labelColor.B);
                        }
                        else
                        {
                            l.BackColor = Color.White;
                            l.ForeColor = SgNet.COM.Form_s.Color(255 - labelColor.R, 255 - labelColor.G, 255 - labelColor.B);
                        }
                    }
                    else if (t != null)
                    {
                        t.Text = infoString;
                        if (labelColor != null)
                        {
                            t.BackColor = labelColor;
                            t.ForeColor = SgNet.COM.Form_s.Color(255 - labelColor.R, 255 - labelColor.G, 255 - labelColor.B);
                        }
                        else
                        {
                            t.BackColor = Color.White;
                            t.ForeColor = SgNet.COM.Form_s.Color(255 - labelColor.R, 255 - labelColor.G, 255 - labelColor.B);
                        }
                    }
                });
            }
            catch/* (Exception e)*/
            {
                //this.Invoke((MethodInvoker)delegate	//スレッドの切替
                //{
                //    MessageBox.Show(e.ToString());
                //});
            }
        }
        //GUIのフォームの色を変える
        void ChangeFormColor(Color formColor)
        {
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                this.BackColor = formColor;
            });
        }
        //GUIへの枚数変更通知
        void ChangeMaisu(List<int> maisu, int rowNo)
        {
        }
        //GUIへの完了通知
        void NotifyComplete(bool errorFlg, String value)
        {
            if (errorFlg)
            {
                FormStatusChange(FormStatus.Error);
            }
            else
            {
                if (SingleFlg == false)
                {
                    if (value == "DateTimeSet")     //DateTimeSetコマンドの場合は何もしない
                    {
                        return;
                    }
                    if (FirstFlg == false)
                    {
                        if (Aging2Flg == false)
                        {
                            //カウントアップ
                            AgingCount++;
                            this.Invoke((MethodInvoker)delegate	//スレッドの切替
                            {
                                label1.Text = AgingCount.ToString() + " / " + AgingEndCount.ToString();
                            });
                        }
                        else
                        {
                            //エージング２中はカウントアップしない
                            Aging2Flg = false;
                            this.Invoke((MethodInvoker)delegate	//スレッドの切替
                            {
                                label4.Text = value + " / " + Aging2EndCount.ToString();
                            });
                        }
                    }
                    else
                    {
                        //最初のリセットの時はカウントアップしない
                        FirstFlg = false;
                        if (Aging2EndCount != 0) {
                            Aging2Flg = true;
                            //エージング２を実行（スレッドで）
                            SgNet.COM.Thread_s.Start(Aging2Thread);
                            return;
                        }
                    }
                    if (AgingCount >= AgingEndCount && AgingEndCount != 0)
                    {
                        //回数が超えたらここ
                        FormStatusChange(FormStatus.Comp);
                    }
                    else
                    {
                        //回数がまだなら
                        if (StopFlg)
                        {
                            //連続の停止
                            FormStatusChange(FormStatus.Wait);
                        }
                        else
                        {
                            //機種毎に変更必要　//エージングの間隔　必要に応じてSleepを入れる*******
                            if (AgingCount == 0)
                            {
                                SgNet.COM.Time_s.Sleep(1000);
                            }
                            else
                            {
                                SgNet.COM.Time_s.Sleep(23000);      //エージング間インターバル２３秒
                            }
                            if (StopFlg == true)
                            {
                                //連続の停止
                                FormStatusChange(FormStatus.Wait);
                                return;
                            }
                            //****************************************************
                            
                            //続きのエージングを実行（スレッドで）
                            SgNet.COM.Thread_s.Start(AgingThread);
                        }
                    }
                }
                else
                {
                    //単発Reset
                    FormStatusChange(FormStatus.Wait);
                }
            }
        }

        //エージングのスレッド開始
        void AgingThread()
        {
            bool ret = StartCmd(AgingCmd, null, -1, -1);//文字列はファイル名の拡張子を除いたもの
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
        }
        void Aging2Thread()
        {
            bool ret = StartCmd(Aging2Cmd, null, -1, -1);//文字列はファイル名の拡張子を除いたもの
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
        }
        //品証ツールなどの複数行まとめて実行時の処理
        void NotifyCompleteMultiLine(List<PatternRow> list)
        {
        }

        /// <summary>
        /// GUIへのプログレスバー変更通知
        /// </summary>
        /// <param name="max">最大値</param>
        /// <param name="val">現在値　※0の時プログレスバーが非表示になる</param>
        void ChangeProgressBar(uint max, uint val)
        {
        }
        //**********************************************

        private void button1_Click(object sender, EventArgs e)
        {
            FormStatusChange(FormStatus.Move);
            ChangeAddress.Parameter = "0";
            bool ret = StartCmd(ChangeAddress, null, -1, -1);
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ForceStop();
            FormStatusChange(FormStatus.Wait);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SQFormShow();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;

            SgNet.COM.File_s.IniFile_s iniP = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\AgingSelect.ini");
            int flg = iniP.ReadInt("Settings", "EndFlg", 0);
            GC.Collect();

            if (flg == 1)
            {
                this.Close();
            }
            else
            {
                timer1.Enabled = true;
            }
        }
    }
    public class Cell
    {
        public int row = 0;
        public int col = 0;
        public String text = "";
        public Cmd tag = null;
        public Cell(int r, int c, object te, object ta)
        {
            row = r;
            col = c;
            text = (String)te;
            tag = (Cmd)ta;
        }
    }
}
