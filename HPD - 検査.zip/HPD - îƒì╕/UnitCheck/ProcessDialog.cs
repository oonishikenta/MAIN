﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Simulator
{
    public partial class ProcessDialog : Form
    {
        [DllImport("KERNEL32.DLL")]
        public static extern uint
            GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, uint nSize, string lpFileName);

        [DllImport("kernel32.dll")]
        private static extern uint WritePrivateProfileString(string lpApplicationName, string lpKeyName, string lpstring, string lpFileName);

        private bool _endFlag = false;

        public Cmd Command;

        public ProcessDialog()
        {
            this.InitializeComponent();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
            WritePrivateProfileString("Pattern", "StopFlag", "True", fPath);
            this._endFlag = true;
        }

        private void ProcessDialog_Load(object sender, EventArgs e)
        {
            var myThread = new Thread(new ThreadStart(ThreadMain));
            myThread.Start();
        }

        private void ThreadMain()
        {
            while (true)
            {
                if (this._endFlag == true)
                {
                    break;
                }
                var sb = new StringBuilder(256);
                var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");

                GetPrivateProfileString("Pattern", "ExecuteFlag", string.Empty, sb, Convert.ToUInt32(sb.Capacity), fPath);
                if (sb.ToString() == "False")
                {
                    Thread.Sleep(10);
                    this.WriteLog(Command);
                    break;
                }
            }

            while (true)
            {
                if (this._endFlag == true)
                {
                    break;
                }

                var sb = new StringBuilder(256);
                var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");

                GetPrivateProfileString("Pattern", "Result", string.Empty, sb, Convert.ToUInt32(sb.Capacity), fPath);

                if (sb.ToString() == "OK")
                {
                    //WritePrivateProfileString("Pattern", "1Sen", "", fPath);
                    //WritePrivateProfileString("Pattern", "2Sen", "", fPath);
                    //WritePrivateProfileString("Pattern", "5Sen", "", fPath);
                    //WritePrivateProfileString("Pattern", "1Man", "", fPath);
                    //WritePrivateProfileString("Pattern", "Result", "NG", fPath);
                    //WritePrivateProfileString("Pattern", "ExecuteFlag", "False", fPath);
                    break;
                }
                GetPrivateProfileString("Pattern", "ExecuteFlag", string.Empty, sb, Convert.ToUInt32(sb.Capacity), fPath);

                Thread.Sleep(10);
            }
            this.Invoke(new Action(() => this.Close()));
        }

        private void WriteLog(Cmd cmd)
        {
            var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
            WritePrivateProfileString("Pattern", "Pat", cmd.FileName, fPath);
            WritePrivateProfileString("Pattern", "1Man", cmd.Maisu[0], fPath);
            WritePrivateProfileString("Pattern", "5Sen", cmd.Maisu[1], fPath);
            WritePrivateProfileString("Pattern", "2Sen", cmd.Maisu[2], fPath);
            WritePrivateProfileString("Pattern", "1Sen", cmd.Maisu[3], fPath);
            WritePrivateProfileString("Pattern", "Result", "NG", fPath);
            WritePrivateProfileString("Pattern", "ExecuteFlag", "True", fPath);
            WritePrivateProfileString("Pattern", "StopFlag", "False", fPath);
        }

        private void ProcessDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
    }
}
